# Clocked In – Chrome Extension

Clocked In is a simple Chrome extension that **blocks distracting or inappropriate websites** and **redirects them to better, more productive pages** so you stay in a focused, “clocked in” state.

By default it blocks popular social media / entertainment sites like:

- facebook.com
- instagram.com
- tiktok.com
- twitter.com / x.com
- reddit.com
- youtube.com
- netflix.com

and redirects them to `https://www.khanacademy.org/`. You can fully customize both the blocked list and the redirect URL.

## How it works

- Uses **Chrome Manifest V3** with `declarativeNetRequest` to create fast, robust redirect rules.
- Rules are generated dynamically from your chosen settings in the options page.
- Settings are stored in `chrome.storage.sync` so they can sync across Chrome if you are signed in.

## Files

- `manifest.json` – Chrome extension manifest (MV3).
- `background.js` – Service worker that builds and applies redirect rules.
- `options.html` / `options.js` – Beautiful settings UI to edit blocked sites and redirect target.

## How to load the extension in Chrome

1. Open Chrome and go to `chrome://extensions/`.
2. Turn on **Developer mode** (toggle in the top-right).
3. Click **“Load unpacked”**.
4. Select the folder: `focus-blocker-extension` (where this README lives).
5. The extension should now appear in your extensions list.

## How to configure

1. In `chrome://extensions/`, find **Clocked In – Focus Blocker**.
2. Click **Details** → **Extension options**.
3. In the options page:
   - Put one domain per line in **Blocked websites** (e.g. `facebook.com`).
   - Set **Redirect to** to any full URL (including `https://`).
4. Click **Save & apply**.
5. Any new tab you open to a blocked site will now be redirected to your chosen URL.

