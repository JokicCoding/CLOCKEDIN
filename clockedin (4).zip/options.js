const DEFAULT_BLOCKED_SITES = [
  "facebook.com",
  "instagram.com",
  "tiktok.com",
  "twitter.com",
  "x.com",
  "reddit.com",
  "youtube.com",
  "netflix.com",
  "pornhub.com",
  "xvideos.com",
  "xnxx.com",
  "onlyfans.com",
  "redtube.com"
];

const DEFAULT_REDIRECT_URL = "https://www.khanacademy.org/";
const DEFAULT_BLOCKED_KEYWORDS = ["porn", "sex", "onlyfans"];

function $(id) {
  return document.getElementById(id);
}

function showStatus(message, type = "ok") {
  const el = $("status");
  el.textContent = message;
  el.classList.remove("ok", "error");
  if (message) {
    el.classList.add(type);
  }
}

function loadOptions() {
  chrome.storage.sync.get(
    {
      blockedSites: DEFAULT_BLOCKED_SITES,
      redirectUrl: DEFAULT_REDIRECT_URL,
      blockedKeywords: DEFAULT_BLOCKED_KEYWORDS
    },
    (items) => {
      $("blockedSites").value = (items.blockedSites || DEFAULT_BLOCKED_SITES).join(
        "\n"
      );
      $("redirectUrl").value = items.redirectUrl || DEFAULT_REDIRECT_URL;
      const kw = items.blockedKeywords;
      const keywordsText = Array.isArray(kw)
        ? kw.join("\n")
        : typeof kw === "string"
          ? kw
          : DEFAULT_BLOCKED_KEYWORDS.join("\n");
      $("blockedKeywords").value = keywordsText;
    }
  );
}

function saveOptions() {
  const blockedRaw = $("blockedSites").value
    .split("\n")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const blockedKeywordsRaw = $("blockedKeywords").value
    .split("\n")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const redirectUrl = $("redirectUrl").value.trim();

  try {
    // Basic validation
    if (!redirectUrl) {
      showStatus("Redirect URL cannot be empty.", "error");
      return;
    }

    // eslint-disable-next-line no-new
    new URL(redirectUrl);
  } catch (e) {
    showStatus("Redirect URL must be a valid URL (including https://).", "error");
    return;
  }

  chrome.storage.sync.set(
    {
      blockedSites: blockedRaw.length > 0 ? blockedRaw : DEFAULT_BLOCKED_SITES,
      blockedKeywords: blockedKeywordsRaw.length > 0 ? blockedKeywordsRaw : DEFAULT_BLOCKED_KEYWORDS,
      redirectUrl
    },
    () => {
      showStatus("Settings saved. New rules are now active.", "ok");
      setTimeout(() => showStatus(""), 3000);
    }
  );
}

function resetDefaults() {
  $("blockedSites").value = DEFAULT_BLOCKED_SITES.join("\n");
  $("redirectUrl").value = DEFAULT_REDIRECT_URL;
  $("blockedKeywords").value = DEFAULT_BLOCKED_KEYWORDS.join("\n");
  saveOptions();
}

document.addEventListener("DOMContentLoaded", () => {
  loadOptions();

  $("save").addEventListener("click", (e) => {
    e.preventDefault();
    saveOptions();
  });

  $("reset").addEventListener("click", (e) => {
    e.preventDefault();
    resetDefaults();
  });
});

