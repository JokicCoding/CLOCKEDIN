/**
 * store.js
 * Badge Store – Clocked In v2
 *
 * Badges are purchased with "Focus Points" earned by blocking distractions.
 * Points = (rescuedSeconds / 60) + (totalRedirects * 5) + (funCount * 2)
 * Owned badge list stored in chrome.storage.sync under "ownedBadges".
 */

// ── Badge catalogue ───────────────────────────────────────────────────────────

const BADGES = [
  // Focus category
  {
    id: "first_block",
    icon: "🛡️",
    name: "First Block",
    desc: "Blocked your very first distraction. The journey begins.",
    cost: 0,
    rarity: "common",
    cat: "focus",
    autoUnlock: true,  // granted free after first redirect
  },
  {
    id: "focus_starter",
    icon: "🎯",
    name: "Focus Starter",
    desc: "Proved you can resist the pull of the feed.",
    cost: 50,
    rarity: "common",
    cat: "focus",
  },
  {
    id: "deep_work",
    icon: "🧠",
    name: "Deep Worker",
    desc: "Saved over 30 minutes of would-be distraction time.",
    cost: 200,
    rarity: "rare",
    cat: "focus",
  },
  {
    id: "flow_state",
    icon: "⚡",
    name: "Flow State",
    desc: "Reached uninterrupted focus. The zone is yours.",
    cost: 500,
    rarity: "epic",
    cat: "focus",
  },
  {
    id: "iron_will",
    icon: "🏰",
    name: "Iron Will",
    desc: "Blocked 100 distractions. Nothing breaks your fortress.",
    cost: 1200,
    rarity: "legendary",
    cat: "focus",
  },
  {
    id: "no_scroll",
    icon: "🚫",
    name: "No Scroll Zone",
    desc: "Kept the doom-scroll demons at bay.",
    cost: 80,
    rarity: "common",
    cat: "focus",
  },

  // Fun category
  {
    id: "truth_seeker",
    icon: "💬",
    name: "Truth Seeker",
    desc: "Played Truth in Family Fun Mode at least once.",
    cost: 30,
    rarity: "common",
    cat: "fun",
  },
  {
    id: "dare_devil",
    icon: "🌶️",
    name: "Dare Devil",
    desc: "Accepted a dare without flinching.",
    cost: 30,
    rarity: "common",
    cat: "fun",
  },
  {
    id: "game_master",
    icon: "🎲",
    name: "Game Master",
    desc: "Played 10 rounds of Family Fun Mode in a single day.",
    cost: 150,
    rarity: "rare",
    cat: "fun",
  },
  {
    id: "laugh_riot",
    icon: "😂",
    name: "Laugh Riot",
    desc: "Made everyone in the room laugh at least once.",
    cost: 300,
    rarity: "epic",
    cat: "fun",
  },

  // Streak category
  {
    id: "two_day",
    icon: "📅",
    name: "Two-Day Focus",
    desc: "Kept your focus for 2 days straight.",
    cost: 60,
    rarity: "common",
    cat: "streak",
  },
  {
    id: "one_week",
    icon: "🔥",
    name: "Week on Fire",
    desc: "A full 7-day focus streak. Incredible discipline.",
    cost: 350,
    rarity: "rare",
    cat: "streak",
  },
  {
    id: "two_weeks",
    icon: "🌟",
    name: "Fortnight Focus",
    desc: "14 consecutive days of staying clocked in.",
    cost: 800,
    rarity: "epic",
    cat: "streak",
  },
  {
    id: "monthly",
    icon: "🏅",
    name: "Month Strong",
    desc: "30 days. You are a productivity legend.",
    cost: 2000,
    rarity: "legendary",
    cat: "streak",
  },

  // Special category
  {
    id: "night_owl",
    icon: "🦉",
    name: "Night Owl",
    desc: "Stayed productive after midnight.",
    cost: 100,
    rarity: "rare",
    cat: "special",
  },
  {
    id: "early_bird",
    icon: "🌅",
    name: "Early Bird",
    desc: "Blocked a distraction before 7 AM.",
    cost: 100,
    rarity: "rare",
    cat: "special",
  },
  {
    id: "digital_zen",
    icon: "🌙",
    name: "Digital Zen",
    desc: "A badge for those who've found true peace with technology.",
    cost: 600,
    rarity: "epic",
    cat: "special",
  },
  {
    id: "wiki_wanderer",
    icon: "📚",
    name: "Wiki Wanderer",
    desc: "Got redirected to Wikipedia 20 times. Accidentally became smarter.",
    cost: 250,
    rarity: "rare",
    cat: "special",
  },
  {
    id: "golden_clock",
    icon: "🏆",
    name: "Golden Clock",
    desc: "The rarest badge. Awarded to those who mastered the clock.",
    cost: 5000,
    rarity: "legendary",
    cat: "special",
  },
  {
    id: "recruiter",
    icon: "🤝",
    name: "Recruiter",
    desc: "Earned by sharing Clocked In with a friend. Can't be bought — only earned!",
    cost: 0,
    rarity: "epic",
    cat: "special",
  },
];

// ── Storage helpers ───────────────────────────────────────────────────────────

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function computePoints(rescuedSeconds, totalRedirects, funCount) {
  return Math.floor((rescuedSeconds / 60) + totalRedirects * 5 + funCount * 2);
}

function loadAll() {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage) {
      chrome.storage.sync.get(
        { rescuedSecondsToday: 0, rescuedDate: "", funCount: 0, funDate: "", ownedBadges: [], totalPoints: 0 },
        (sync) => {
          chrome.storage.local.get({ totalRedirects: 0, browsingDate: "" }, (local) => {
            resolve({ sync, local });
          });
        }
      );
    } else {
      // Demo fallback when loaded outside extension context
      resolve({
        sync: { rescuedSecondsToday: 3600, rescuedDate: todayKey(), funCount: 5, funDate: todayKey(), ownedBadges: [], totalPoints: 0 },
        local: { totalRedirects: 42 }
      });
    }
  });
}

function saveOwned(ownedBadges, spentPoints) {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage) {
      chrome.storage.sync.set({ ownedBadges, spentPoints }, resolve);
    } else {
      resolve();
    }
  });
}

// ── Toast ─────────────────────────────────────────────────────────────────────

let toastTimer = null;

function showToast(msg) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}

// ── Render ────────────────────────────────────────────────────────────────────

let currentPoints = 0;
let ownedBadges = [];
let spentPoints = 0;
let currentCat = "all";

function renderShowcase() {
  const grid = document.getElementById("showcaseGrid");
  if (!grid) return;

  const owned = BADGES.filter(b => ownedBadges.includes(b.id));
  if (owned.length === 0) {
    grid.innerHTML = `<span class="showcase-empty">No badges yet — visit the store below!</span>`;
    return;
  }
  grid.innerHTML = owned
    .map(b => `<div class="showcase-badge">${b.icon} ${b.name}</div>`)
    .join("");
}

function renderGrid(cat) {
  const grid = document.getElementById("badgeGrid");
  if (!grid) return;

  const filtered = cat === "all" ? BADGES : BADGES.filter(b => b.cat === cat);

  grid.innerHTML = "";
  filtered.forEach(badge => {
    const isOwned = ownedBadges.includes(badge.id);
    const canAfford = currentPoints >= badge.cost;
    const card = document.createElement("div");
    card.className = `badge-card ${badge.rarity}${isOwned ? " owned" : ""}`;

    let btnHtml;
    if (isOwned) {
      btnHtml = `<button class="buy-btn owned-btn" disabled>✓ Owned</button>`;
    } else if (badge.cost === 0) {
      btnHtml = `<button class="buy-btn" data-id="${badge.id}">Free!</button>`;
    } else if (!canAfford) {
      btnHtml = `<button class="buy-btn cant-afford" disabled title="Need ${badge.cost - currentPoints} more points">🔒 ${badge.cost.toLocaleString()} pts</button>`;
    } else {
      btnHtml = `<button class="buy-btn" data-id="${badge.id}">Buy · ${badge.cost.toLocaleString()} pts</button>`;
    }

    card.innerHTML = `
      <div class="badge-icon">${badge.icon}</div>
      <div class="badge-meta">
        <div class="badge-name">${badge.name}</div>
        <div class="badge-desc">${badge.desc}</div>
      </div>
      <div class="badge-footer">
        <span class="rarity-tag">${badge.rarity}</span>
        ${btnHtml}
      </div>
    `;

    // Buy handler
    const btn = card.querySelector(".buy-btn[data-id]");
    if (btn) {
      btn.addEventListener("click", () => purchaseBadge(badge));
    }

    grid.appendChild(card);
  });
}

async function purchaseBadge(badge) {
  if (ownedBadges.includes(badge.id)) return;
  if (currentPoints < badge.cost) {
    showToast(`Need ${(badge.cost - currentPoints).toLocaleString()} more points to unlock ${badge.name}`);
    return;
  }

  ownedBadges = [...ownedBadges, badge.id];
  spentPoints += badge.cost;
  currentPoints -= badge.cost;

  await saveOwned(ownedBadges, spentPoints);

  // Update balance display
  document.getElementById("balanceDisplay").textContent = currentPoints.toLocaleString();
  document.getElementById("ownedCount").textContent = ownedBadges.length;

  renderShowcase();
  renderGrid(currentCat);
  showToast(`🎉 ${badge.icon} "${badge.name}" added to your collection!`);
}

// ── Init ──────────────────────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", async () => {
  const { sync, local } = await loadAll();

  const today = todayKey();
  const rescuedSecs = sync.rescuedDate === today ? (sync.rescuedSecondsToday || 0) : 0;
  const totalRedirects = local.totalRedirects || 0;
  const funCount = sync.funDate === today ? (sync.funCount || 0) : 0;

  const earned = computePoints(rescuedSecs, totalRedirects, funCount);
  spentPoints = sync.spentPoints || 0;
  currentPoints = Math.max(0, earned - spentPoints);
  ownedBadges = sync.ownedBadges || [];

  // Auto-unlock free/first_block badge if redirects >= 1
  if (totalRedirects >= 1 && !ownedBadges.includes("first_block")) {
    ownedBadges = [...ownedBadges, "first_block"];
    await saveOwned(ownedBadges, spentPoints);
  }

  document.getElementById("balanceDisplay").textContent = currentPoints.toLocaleString();
  document.getElementById("ownedCount").textContent = ownedBadges.length;

  renderShowcase();
  renderGrid("all");

  // Category tabs
  document.querySelectorAll(".cat-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".cat-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      currentCat = tab.dataset.cat;
      renderGrid(currentCat);
    });
  });
});
