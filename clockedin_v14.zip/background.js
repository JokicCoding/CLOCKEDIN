/**
 * background.js — Clocked In v8
 * MV3 service worker.
 *
 * BLOCKING PHILOSOPHY:
 * - NO hardcoded block lists. User controls everything.
 * - Schedule: blocking only active during user-defined windows + days.
 * - Allowed pages always win over blocked sites/keywords.
 */

const DEFAULT_DISTRACTION_SITES = [
  "youtube.com","tiktok.com","instagram.com","facebook.com",
  "twitter.com","x.com","reddit.com","netflix.com","twitch.tv",
  "pinterest.com","snapchat.com","tumblr.com","discord.com",
  "9gag.com","buzzfeed.com","imgur.com"
];

const DEFAULT_BLOCKED_KEYWORDS = [];

// Default schedule: Mon–Fri, 9am–6pm
const DEFAULT_SCHEDULE = {
  enabled: false,          // false = always block (no schedule restriction)
  days: [1,2,3,4,5],       // 0=Sun,1=Mon…6=Sat
  startHour: 9,
  startMin: 0,
  endHour: 18,
  endMin: 0
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

/**
 * isWithinSchedule — returns true if blocking should be active right now.
 * If schedule.enabled is false, blocking is always active (old behaviour).
 */
function isWithinSchedule(schedule) {
  if (!schedule || !schedule.enabled) return true; // no schedule = always on

  const now = new Date();
  const day = now.getDay();   // 0=Sun … 6=Sat
  const hour = now.getHours();
  const min = now.getMinutes();

  // Check day
  if (!schedule.days.includes(day)) return false;

  // Check time window
  const nowMins = hour * 60 + min;
  const startMins = (schedule.startHour || 0) * 60 + (schedule.startMin || 0);
  const endMins   = (schedule.endHour   || 23) * 60 + (schedule.endMin   || 59);

  return nowMins >= startMins && nowMins < endMins;
}

async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({
      blockedSites: DEFAULT_DISTRACTION_SITES,
      blockedKeywords: DEFAULT_BLOCKED_KEYWORDS,
      allowedPages: [],
      redirectUrl: "https://www.wikipedia.org/",
      schedule: DEFAULT_SCHEDULE
    }, (items) => resolve({
      blockedSites: Array.isArray(items.blockedSites) ? items.blockedSites : DEFAULT_DISTRACTION_SITES,
      blockedKeywords: Array.isArray(items.blockedKeywords) ? items.blockedKeywords : [],
      allowedPages: Array.isArray(items.allowedPages) ? items.allowedPages : [],
      redirectUrl: items.redirectUrl || "https://www.wikipedia.org/",
      schedule: items.schedule || DEFAULT_SCHEDULE
    }));
  });
}

/**
 * isAllowed — whitelist check. Allowed pages always pass through.
 */
function isAllowed(url, allowedPages) {
  if (!allowedPages || allowedPages.length === 0) return false;
  const lower = url.toLowerCase();
  for (const pattern of allowedPages) {
    const p = pattern.trim().toLowerCase();
    if (p && lower.includes(p)) return true;
  }
  return false;
}

/**
 * classifyUrl — "distraction" | null
 * Schedule + whitelist both checked before blocked lists.
 */
function classifyUrl(url, blockedSites, blockedKeywords, allowedPages, schedule) {
  if (!url || !url.startsWith("http")) return null;

  // Schedule gate — if outside active window, nothing is blocked
  if (!isWithinSchedule(schedule)) return null;

  // Whitelist — allowed pages always pass through
  if (isAllowed(url, allowedPages)) return null;

  const lower = url.toLowerCase();

  for (const site of blockedSites) {
    const s = site.trim().toLowerCase();
    if (s && lower.includes(s)) return "distraction";
  }

  for (const kw of blockedKeywords) {
    const k = kw.trim().toLowerCase();
    if (k && lower.includes(k)) return "distraction";
  }

  return null;
}

// ── Browsing time tracking ────────────────────────────────────────────────────

let activeTabId = null;
let activeStart = null;

async function flushTime() {
  if (activeStart === null) return;
  const elapsed = Math.floor((Date.now() - activeStart) / 1000);
  activeStart = Date.now();
  if (elapsed <= 0) return;
  const today = todayKey();
  chrome.storage.local.get({ browsingDate: "", browsingSeconds: 0 }, (data) => {
    const base = data.browsingDate === today ? data.browsingSeconds : 0;
    chrome.storage.local.set({ browsingDate: today, browsingSeconds: base + elapsed });
  });
}

function startTracking(tabId) { flushTime(); activeTabId = tabId; activeStart = Date.now(); }
function stopTracking()        { flushTime(); activeTabId = null;  activeStart = null; }

chrome.alarms.create("flushBrowsingTime", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flushBrowsingTime") flushTime();
});

chrome.tabs.onActivated.addListener(({ tabId }) => startTracking(tabId));
chrome.tabs.onRemoved.addListener((tabId) => { if (tabId === activeTabId) stopTracking(); });

// ── Blocking ──────────────────────────────────────────────────────────────────

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "loading") return;
  if (!tab.url) return;

  const extBase = chrome.runtime.getURL("");
  if (tab.url.startsWith(extBase)) return;

  const { blockedSites, blockedKeywords, allowedPages, schedule } = await getSettings();
  const verdict = classifyUrl(tab.url, blockedSites, blockedKeywords, allowedPages, schedule);

  if (verdict === "distraction") {
    const encoded = encodeURIComponent(tab.url);
    chrome.tabs.update(tabId, { url: chrome.runtime.getURL(`fun.html?from=${encoded}`) });
    chrome.storage.local.get({ totalRedirects: 0 }, (d) => {
      chrome.storage.local.set({ totalRedirects: d.totalRedirects + 1 });
    });
  }
});

// ── Install / Update ──────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.storage.sync.set({
      blockedSites: DEFAULT_DISTRACTION_SITES,
      blockedKeywords: DEFAULT_BLOCKED_KEYWORDS,
      allowedPages: [],
      redirectUrl: "https://www.wikipedia.org/",
      schedule: DEFAULT_SCHEDULE
    });
  } else if (details.reason === "update") {
    chrome.storage.sync.get({ blockedSites: DEFAULT_DISTRACTION_SITES, blockedKeywords: null }, (items) => {
      const updates = {};
      const oldPornKeywords = ["porn","xxx","hentai","onlyfans","camgirl","livecam","sexcam","sex"];
      if (!items.blockedKeywords || !Array.isArray(items.blockedKeywords)) {
        updates.blockedKeywords = [];
      } else {
        updates.blockedKeywords = items.blockedKeywords.filter(
          kw => !oldPornKeywords.includes(kw.toLowerCase().trim())
        );
      }
      const oldAlwaysBlocked = [
        "pornhub.com","xvideos.com","xnxx.com","onlyfans.com","redtube.com",
        "youporn.com","tube8.com","spankbang.com","xhamster.com","beeg.com",
        "porn.com","sex.com","chaturbate.com","bongacams.com","cam4.com",
        "myfreecams.com","livejasmin.com","stripchat.com","cams.com",
        "adultfriendfinder.com","ashleymadison.com","fetlife.com",
        "brazzers.com","bangbros.com","fansly.com","rule34.xxx",
        "e-hentai.org","nhentai.net","bet365.com","draftkings.com",
        "fanduel.com","betway.com","888casino.com","pokerstars.com",
        "stake.com","roobet.com","stormfront.org","gab.com","kiwifarms.net"
      ];
      if (Array.isArray(items.blockedSites)) {
        updates.blockedSites = items.blockedSites.filter(
          s => !oldAlwaysBlocked.includes(s.toLowerCase().trim())
        );
      }
      chrome.storage.sync.set(updates);
    });
  }

  chrome.alarms.create("flushBrowsingTime", { periodInMinutes: 0.5 });
  chrome.alarms.create("checkStreak", { periodInMinutes: 60 });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("flushBrowsingTime", { periodInMinutes: 0.5 });
  chrome.alarms.create("checkStreak", { periodInMinutes: 60 });
});

// ── Streak tracking ───────────────────────────────────────────────────────────

function checkStreak() {
  const today = todayKey();
  chrome.storage.sync.get({ streakDays: 0, lastActiveDate: "", streakNotified: "" }, (data) => {
    if (data.lastActiveDate === today) return;
    const yesterday = (() => {
      const d = new Date(); d.setDate(d.getDate()-1);
      return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
    })();
    const newStreak = data.lastActiveDate === yesterday ? data.streakDays + 1 : 1;
    chrome.storage.sync.set({ streakDays: newStreak, lastActiveDate: today });
  });
}

function checkStreakNotification() {
  const today = todayKey();
  chrome.storage.sync.get({ lastActiveDate: "", streakDays: 0, streakNotified: "" }, (data) => {
    if (data.streakNotified === today) return;
    if (data.lastActiveDate === today) return;
    if (data.streakDays < 1) return;
    chrome.notifications.create("streakWarning", {
      type: "basic", iconUrl: "icons/icon128.png",
      title: "⚠️ Don't break your streak!",
      message: `You have a ${data.streakDays}-day focus streak 🔥 Open Clocked In to keep it alive!`,
      priority: 2
    });
    chrome.storage.sync.set({ streakNotified: today });
  });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "checkStreak") {
    checkStreak();
    if (new Date().getHours() >= 21) checkStreakNotification();
  }
});

chrome.tabs.onUpdated.addListener(() => checkStreak());
