const DEFAULT_EDUCATIONAL_SITES = [
  // Knowledge & Learning
  "https://www.wikipedia.org/",
  "https://www.britannica.com/",
  "https://www.edx.org/",
  "https://ocw.mit.edu/",
  "https://www.freecodecamp.org/learn/",
  "https://www.coursera.org/",
  "https://www.codecademy.com/",
  "https://www.khanacademy.org/",
  "https://www.skillshare.com/",
  "https://www.udemy.com/",
  // News & Current Events
  "https://www.bbc.com/news",
  "https://www.reuters.com/",
  "https://apnews.com/",
  "https://www.theguardian.com/",
  "https://www.nationalgeographic.com/",
  // Science & Nature
  "https://www.nasa.gov/",
  "https://www.scientificamerican.com/",
  "https://www.newscientist.com/",
  "https://www.nature.com/",
  // Health & Fitness
  "https://www.healthline.com/",
  "https://www.webmd.com/",
  "https://www.mayoclinic.org/",
  // Finance & Investing
  "https://www.investopedia.com/",
  "https://www.nerdwallet.com/",
  // Language Learning
  "https://www.duolingo.com/",
  "https://www.babbel.com/",
  "https://www.memrise.com/",
  // Meditation & Mindfulness
  "https://www.headspace.com/meditation/meditation-for-beginners",
  "https://www.calm.com/",
  "https://www.mindful.org/",
  // Motivation & Self Improvement
  "https://www.ted.com/talks",
  "https://jamesclear.com/articles",
  "https://www.markmanson.net/articles",
  "https://www.success.com/",
  "https://medium.com/self-improvement",
];

const COUNTDOWN_SECONDS = 3;

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  if (s < 60) return `${s}s`;
  const minutes = Math.floor(s / 60);
  const seconds = s % 60;
  if (minutes < 60) return seconds ? `${minutes}m ${seconds}s` : `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remMinutes = minutes % 60;
  if (remMinutes === 0) return `${hours}h`;
  return `${hours}h ${remMinutes}m`;
}

/** Pick a random site from the pool */
function pickRandom(pool) {
  return pool[Math.floor(Math.random() * pool.length)];
}

function startCountdown(targetSeconds, onDone) {
  const countEl = document.getElementById("count");
  const progressEl = document.getElementById("progress");
  const totalMs = targetSeconds * 1000;
  const started = Date.now();

  function tick() {
    const elapsed = Date.now() - started;
    const remainingMs = Math.max(0, totalMs - elapsed);
    const remainingSeconds = Math.ceil(remainingMs / 1000);
    if (countEl) countEl.textContent = String(remainingSeconds);
    if (progressEl) progressEl.style.transform = `scaleX(${Math.min(1, elapsed / totalMs)})`;
    if (remainingMs <= 0) {
      if (typeof onDone === "function") onDone();
    } else {
      requestAnimationFrame(tick);
    }
  }
  requestAnimationFrame(tick);
}

/** Live browsing time counter that updates every second */
function startBrowsingTimer(baseSeconds, baseDate) {
  const el = document.getElementById("browsingTime");
  if (!el) return;

  const today = todayKey();
  const validBase = baseDate === today ? baseSeconds : 0;
  let extra = 0;

  function tick() {
    el.textContent = formatDuration(validBase + extra);
    extra++;
    setTimeout(tick, 1000);
  }
  tick();
}

document.addEventListener("DOMContentLoaded", () => {
  const sitesListEl = document.getElementById("sitesList");
  const rescuedTimeEl = document.getElementById("rescuedTime");

  // Load both sync (rescued time) and local (browsing time) storage
  chrome.storage.sync.get(
    { rescuedSecondsToday: 0, rescuedDate: "" },
    (syncData) => {
      chrome.storage.local.get(
        { browsingSeconds: 0, browsingDate: "" },
        (localData) => {
          // Rescued time
          const today = todayKey();
          const alreadyToday = syncData.rescuedDate === today;
          const rescuedBase = alreadyToday ? Number(syncData.rescuedSecondsToday || 0) : 0;
          if (rescuedTimeEl) rescuedTimeEl.textContent = formatDuration(rescuedBase);

          // Browsing time — live counter
          startBrowsingTimer(localData.browsingSeconds, localData.browsingDate);

          // Pick a random redirect target
          const target = pickRandom(DEFAULT_EDUCATIONAL_SITES);

          if (sitesListEl) {
            const sample = DEFAULT_EDUCATIONAL_SITES
              .sort(() => 0.5 - Math.random())
              .slice(0, 4)
              .map(url => new URL(url).hostname.replace("www.", ""));
            sitesListEl.textContent = `${sample.join(", ")}, and more.`;
          }

          startCountdown(COUNTDOWN_SECONDS, () => {
            const updatedSeconds = rescuedBase + COUNTDOWN_SECONDS;
            chrome.storage.sync.set(
              { rescuedSecondsToday: updatedSeconds, rescuedDate: today },
              () => {
                if (rescuedTimeEl) rescuedTimeEl.textContent = formatDuration(updatedSeconds);
                window.location.replace(target);
              }
            );
          });
        }
      );
    }
  );
});
