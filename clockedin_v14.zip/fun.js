/**
 * fun.js — Clocked In v10
 * Family Fun Mode: Truth & Dare + Productivity Mini-Games
 */

// ── Helpers ───────────────────────────────────────────────────────────────────
function pickRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function shuffle(arr) { return [...arr].sort(() => Math.random() - 0.5); }
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function formatDuration(totalSeconds) {
  const s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  if (s < 60) return `${s}s`;
  const mins = Math.floor(s / 60), secs = s % 60;
  if (mins < 60) return secs ? `${mins}m ${secs}s` : `${mins}m`;
  const hrs = Math.floor(mins / 60), rem = mins % 60;
  return rem === 0 ? `${hrs}h` : `${hrs}h ${rem}m`;
}
function animateIn(el) {
  el.style.opacity = "0";
  el.style.transform = "translateY(10px)";
  el.style.transition = "opacity 0.35s ease, transform 0.35s ease";
  requestAnimationFrame(() => requestAnimationFrame(() => {
    el.style.opacity = "1";
    el.style.transform = "translateY(0)";
  }));
}

// ── Truth & Dare Data ─────────────────────────────────────────────────────────
const TRUTHS = [
  { text: "What are you actually avoiding right now — and be honest about why.", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "How many tabs do you have open right now? List what every single one of them is.", timer: null, textbox: true, category: "self-aware", difficulty: 1 },
  { text: "Write down exactly what you need to finish today. No vague stuff.", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "If your future self could see what you're doing right now, what would they say?", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "What's the one task you keep pushing to tomorrow? Write it AND the exact time you'll do it.", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "Rate your focus today 1–10 and explain why it's not a 10.", timer: null, textbox: true, category: "self-aware", difficulty: 1 },
  { text: "Name three things stressing you out right now. Getting them out of your head actually helps.", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "What would you need to do today to feel genuinely proud of yourself tonight?", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "Write the very first sentence of whatever you're supposed to be working on right now.", timer: null, textbox: true, category: "self-aware", difficulty: 3 },
  { text: "What skill do you want to have in 5 years that you haven't started learning yet?", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "If you could only keep 3 apps on your phone, which 3 — and what does that say about you?", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "What's something you tell yourself is 'just a small break' that always turns into an hour?", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "What's your actual sleep schedule been like this week vs what you wish it was?", timer: null, textbox: true, category: "self-aware", difficulty: 1 },
  { text: "If you had to give your current work ethic a mascot, what would it be and why?", timer: null, textbox: true, category: "fun", difficulty: 1 },
  { text: "What's the worst excuse you've ever given a teacher for not doing something?", timer: null, textbox: false, category: "student", difficulty: 1 },
  { text: "What subject do you pretend to understand but actually have no idea about?", timer: null, textbox: false, category: "student", difficulty: 2 },
  { text: "What's the latest you've ever stayed up before an exam and how did it go?", timer: null, textbox: false, category: "student", difficulty: 1 },
  { text: "When's the last time you actually read the whole assignment without skimming?", timer: null, textbox: false, category: "student", difficulty: 2 },
  { text: "What app do you waste the most time on? Be honest — you know the screen time number.", timer: null, textbox: false, category: "student", difficulty: 1 },
  { text: "What's your go-to strategy when you haven't done the reading?", timer: null, textbox: false, category: "student", difficulty: 1 },
  { text: "What's the most niche rabbit hole you've gone down instead of studying?", timer: null, textbox: false, category: "fun", difficulty: 1 },
  { text: "If your study habits were a movie genre, what would it be and why?", timer: null, textbox: false, category: "fun", difficulty: 1 },
  { text: "What genuinely makes you feel motivated when nothing else does?", timer: null, textbox: false, category: "self-aware", difficulty: 2 },
  { text: "Describe your procrastination style in exactly three words.", timer: null, textbox: false, category: "fun", difficulty: 1 },
  { text: "What's one belief about yourself that might actually be holding you back?", timer: null, textbox: true, category: "self-aware", difficulty: 3 },
  { text: "If you couldn't use social media for a week, what would you do with that time?", timer: null, textbox: true, category: "focus", difficulty: 2 },
  { text: "What does 'being productive' actually mean to you — not the textbook answer, the real one?", timer: null, textbox: true, category: "focus", difficulty: 3 },
  { text: "What would you work on if you knew you couldn't fail?", timer: null, textbox: true, category: "self-aware", difficulty: 3 },
  { text: "What's a grade you got that you know you could've done better on? What actually went wrong?", timer: null, textbox: false, category: "student", difficulty: 2 },
  { text: "What does your ideal study setup look like vs what it looks like right now?", timer: null, textbox: false, category: "student", difficulty: 1 },
];

const DARES = [
  { text: "Close every tab that isn't directly related to what you're supposed to be doing. All of them. Now.", timer: 30, textbox: false, category: "focus", difficulty: 2 },
  { text: "Set a 25-minute focus timer and commit to zero phone until it goes off.", timer: 1500, textbox: false, category: "focus", difficulty: 3 },
  { text: "Read one full page of whatever you're studying without re-reading a single sentence.", timer: 300, textbox: false, category: "focus", difficulty: 2 },
  { text: "Put your phone face-down in another room for the next 20 minutes.", timer: 1200, textbox: false, category: "focus", difficulty: 3 },
  { text: "Do 10 practice questions, problems, or flashcards right now. No skipping.", timer: 600, textbox: false, category: "focus", difficulty: 2 },
  { text: "Clean your desk completely before you do anything else. Chaos kills focus.", timer: 180, textbox: false, category: "focus", difficulty: 1 },
  { text: "Drink a full glass of water before you open any other tab.", timer: 60, textbox: false, category: "focus", difficulty: 1 },
  { text: "Go through your notifications and mute every app that isn't urgent for the next hour.", timer: 120, textbox: false, category: "focus", difficulty: 2 },
  { text: "Write a 5-sentence explanation of what you're studying as if you're teaching a 10-year-old.", timer: null, textbox: true, category: "focus", difficulty: 2 },
  { text: "Write your top 3 goals for this week. Be specific. No vague stuff. GO.", timer: null, textbox: true, category: "self-aware", difficulty: 2 },
  { text: "Write a strongly-worded pep talk to yourself in second person. Make it actually motivating.", timer: null, textbox: true, category: "fun", difficulty: 2 },
  { text: "Write a 3-sentence summary of what you just studied from memory. No peeking.", timer: null, textbox: true, category: "focus", difficulty: 3 },
  { text: "Roast yourself for how you've been spending your time today. Be brutally honest.", timer: null, textbox: true, category: "fun", difficulty: 2 },
  { text: "Write the worst possible opening sentence for an essay on what you're studying. Make it genuinely terrible.", timer: null, textbox: true, category: "fun", difficulty: 1 },
  { text: "Write a LinkedIn post about your study session today. Motivational and extremely cringey. Full send.", timer: null, textbox: true, category: "fun", difficulty: 1 },
  { text: "Write a haiku about your current mood. 5-7-5 syllables. Make it poetic.", timer: null, textbox: true, category: "fun", difficulty: 1 },
  { text: "In one sentence, explain what you'll regret most if you don't finish what you're working on.", timer: null, textbox: true, category: "self-aware", difficulty: 3 },
  { text: "Do 20 squats. Yes right now. Chair half-squats still count.", timer: 60, textbox: false, category: "fun", difficulty: 1 },
  { text: "Do your best impression of your most boring teacher out loud. No audience required.", timer: 30, textbox: false, category: "fun", difficulty: 1 },
  { text: "Say your full name, your current assignment, and your deadline out loud. Manifesting.", timer: 20, textbox: false, category: "fun", difficulty: 1 },
  { text: "Do 15 jumping jacks. It literally increases blood flow to your brain.", timer: 30, textbox: false, category: "fun", difficulty: 1 },
  { text: "Hold a plank for 30 seconds. If you can do this you can do anything.", timer: 35, textbox: false, category: "fun", difficulty: 2 },
  { text: "Explain your current assignment out loud in one sentence like you're pitching it on Shark Tank.", timer: 30, textbox: false, category: "fun", difficulty: 2 },
  { text: "Box breathe: in for 4, hold for 4, out for 4, hold for 4. Do it 3 times. Right now.", timer: 50, textbox: false, category: "focus", difficulty: 1 },
  { text: "Speak in a robot voice for the next 60 seconds. Everything you say must be monotone.", timer: 60, textbox: false, category: "fun", difficulty: 1 },
  { text: "Stand up, roll your shoulders back, stretch your arms overhead for 10 full seconds.", timer: 20, textbox: false, category: "focus", difficulty: 1 },
  { text: "Find something on your desk that doesn't belong there and put it away right now.", timer: 30, textbox: false, category: "focus", difficulty: 1 },
];

// ── Timer ─────────────────────────────────────────────────────────────────────
let timerInterval = null;
let timerRemaining = 0;
let timerTotal = 0;
let timerRunning = false;

function startTimer(seconds) {
  clearInterval(timerInterval);
  timerRemaining = seconds;
  timerTotal = seconds;
  timerRunning = true;
  renderTimer();
  timerInterval = setInterval(() => {
    if (!timerRunning) return;
    timerRemaining--;
    renderTimer();
    if (timerRemaining <= 0) { clearInterval(timerInterval); timerRunning = false; onTimerDone(); }
  }, 1000);
}

function renderTimer() {
  const wrap = document.getElementById("timerWrap");
  const numEl = document.getElementById("timerNum");
  const arcEl = document.getElementById("timerArc");
  const pauseBtn = document.getElementById("timerPauseBtn");
  if (!wrap) return;
  const pct = timerTotal > 0 ? (timerRemaining / timerTotal) : 0;
  const circ = 2 * Math.PI * 28;
  arcEl.style.strokeDashoffset = circ * (1 - pct);
  const mins = Math.floor(timerRemaining / 60), secs = timerRemaining % 60;
  numEl.textContent = mins > 0 ? `${mins}:${String(secs).padStart(2,"0")}` : `${timerRemaining}`;
  pauseBtn.textContent = timerRunning ? "⏸ Pause" : "▶ Resume";
  wrap.classList.toggle("urgent", timerRemaining <= 5 && timerRemaining > 0);
}

function onTimerDone() {
  const wrap = document.getElementById("timerWrap");
  const numEl = document.getElementById("timerNum");
  if (numEl) numEl.textContent = "✓";
  if (wrap) { wrap.classList.add("done"); setTimeout(() => wrap.classList.remove("done"), 3000); }
}

function stopTimer() { clearInterval(timerInterval); timerRunning = false; timerRemaining = 0; }

// ── AI Response ───────────────────────────────────────────────────────────────
async function getAIResponse(question, userAnswer, mode) {
  const aiBox = document.getElementById("aiResponseBox");
  const aiText = document.getElementById("aiResponseText");
  aiBox.style.display = "block";
  aiText.textContent = "Thinking…";
  animateIn(aiBox);

  const FALLBACKS = ["lmaoo that's actually so real 💀","no bc why is that so relatable lol","ok but that's genuinely a vibe 😭","LMAO ok noted, respect tho fr","bro that's actually lowkey iconic 💅","not me cackling at this 😭😭","ok that's sending me lol","no way fr?? that's wild 💀"];
  const prompt = mode === "dare"
    ? `You are "Clocked In", the hype AI host of a productivity app's dare game. The user just completed a dare. React in 2-3 sentences: be encouraging, hype, and fun — use casual internet language (lol, omg, fr, lowkey, no way, ok but, etc). Keep it family-friendly.\n\nDare: "${question}"\nResponse: "${userAnswer}"\n\nReact directly — no intro.`
    : `You are "Clocked In", the fun AI host of a focus app's truth game. React to the player's honest answer in 2-3 sentences. Be hype, funny, genuine — use casual internet language (lol, lmao, omg, fr, no way, lowkey, ok but, etc). Family-friendly.\n\nTruth: "${question}"\nAnswer: "${userAnswer}"\n\nReact directly — no intro.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] })
    });
    const data = await response.json();
    const reply = data.content?.map(b => b.text || "").join("") || FALLBACKS[0];
    aiText.textContent = reply;
    animateIn(aiText);
  } catch { aiText.textContent = FALLBACKS[Math.floor(Math.random() * FALLBACKS.length)]; }
}

// ── Truth & Dare ──────────────────────────────────────────────────────────────
let currentChallenge = null;
let tdStreak = 0;

function showChallenge(type) {
  const pool = type === "truth" ? TRUTHS : DARES;
  const cat = document.getElementById("tdCategory")?.value || "all";
  const diff = parseInt(document.getElementById("tdDifficulty")?.value || "0");
  let filtered = pool;
  if (cat !== "all") filtered = filtered.filter(c => c.category === cat);
  if (diff > 0) filtered = filtered.filter(c => c.difficulty === diff);
  if (filtered.length === 0) filtered = pool;

  const challenge = pickRandom(filtered);
  currentChallenge = { ...challenge, type };

  document.getElementById("aiResponseBox").style.display = "none";
  document.getElementById("answerInput").value = "";
  stopTimer();

  const typeEl = document.getElementById("challengeType");
  typeEl.textContent = type === "truth" ? "✨ Truth" : "⚡ Dare";
  typeEl.className = "challenge-type " + type;

  const stars = ["","🌱 Easy","🔥 Medium","💀 Spicy"];
  const diffEl = document.getElementById("challengeDiff");
  if (diffEl) diffEl.textContent = stars[challenge.difficulty] || "";

  const catLabels = { "self-aware": "🪞 Self-Aware", "student": "📚 Student", "focus": "🎯 Focus", "fun": "😂 Fun" };
  const catEl = document.getElementById("challengeCat");
  if (catEl) catEl.textContent = catLabels[challenge.category] || "";

  document.getElementById("challengeText").textContent = challenge.text;

  const timerWrap = document.getElementById("timerWrap");
  if (challenge.timer) {
    timerWrap.style.display = "flex";
    timerWrap.classList.remove("urgent","done");
    document.getElementById("timerArc").style.strokeDashoffset = 0;
    startTimer(challenge.timer);
  } else {
    timerWrap.style.display = "none";
  }
  document.getElementById("textboxWrap").style.display = challenge.textbox ? "block" : "none";

  document.getElementById("tdButtonArea").style.display = "none";
  const resultArea = document.getElementById("tdResultArea");
  resultArea.style.display = "block";
  animateIn(document.getElementById("resultPanel"));

  tdStreak++;
  const streakEl = document.getElementById("tdStreakCount");
  if (streakEl) streakEl.textContent = tdStreak;
  trackFunCount();
}

function resetTDToButtons() {
  stopTimer();
  document.getElementById("tdButtonArea").style.display = "flex";
  document.getElementById("tdResultArea").style.display = "none";
  document.getElementById("aiResponseBox").style.display = "none";
}

function trackFunCount() {
  const today = todayKey();
  chrome.storage.sync.get({ funCount: 0, funDate: "" }, (data) => {
    const base = data.funDate === today ? data.funCount : 0;
    chrome.storage.sync.set({ funCount: base + 1, funDate: today });
    const el = document.getElementById("funCount");
    if (el) el.textContent = base + 1;
  });
}

// ── 1. Typing Sprint ──────────────────────────────────────────────────────────
const TYPING_SENTENCES = {
  easy: [
    "Focus is the art of knowing what to ignore.",
    "Small steps lead to big results over time.",
    "Your phone can wait. Your future self cannot.",
    "Work hard in silence. Let success make the noise.",
    "Motivation gets you started. Habit keeps you going.",
    "Every expert was once a beginner who refused to quit.",
    "A year from now you will wish you had started today.",
  ],
  medium: [
    "Discipline is choosing between what you want now and what you want most. Deep work produces the results that shallow work only promises. The best time to start was yesterday. The second best time is now. Success is not final and failure is not fatal — it is the courage to continue that counts.",
    "An investment in knowledge pays the best interest every single time. The secret of getting ahead is getting started no matter what. Focus on being productive instead of busy. Great things are done by a series of small things brought together with intention.",
    "You do not rise to the level of your goals. You fall to the level of your systems. Build better systems and the results will follow. Stop waiting for motivation and start building discipline. Clarity comes from action, not from thinking about action.",
    "The difference between who you are and who you want to be is what you do. Procrastination is not laziness — it is fear wearing a disguise. Do the hard thing first and the rest of your day gets easier. Progress compounds just like interest does.",
    "Your attention is your most valuable resource — spend it on what actually matters. Most urgent things are not important and most important things are not urgent. Learn to tell the difference and protect your time like it belongs to you. Because it does.",
  ],
  hard: [
    "The quality of your life is determined by the quality of your habits. You do not need to be motivated to be consistent — you need a system. Motivation is a feeling that comes and goes like the weather, but discipline is a skill you can train. Most people overestimate what they can do in a day and underestimate what they can do in a year. The gap between where you are and where you want to be is filled by nothing but daily action. Stop waiting for the right moment because the right moment is always right now. You will regret the things you did not do far more than the ones you did. Build momentum by starting small, staying consistent, and refusing to stop when it gets hard.",
    "Success is not about talent — it is about showing up when you do not feel like it. The people who achieve the most are not always the most gifted. They are the ones who refuse to let a bad day become a bad week. Every hour you protect for deep work is an investment that pays dividends for years. Your phone is designed by some of the smartest engineers in the world to capture your attention. You have to be intentional to win that battle. Delete the apps. Set the timers. Do the work. Nobody is coming to save you and that is actually the most liberating thing you can realize. You are the author of this story. Start writing the version you actually want to read.",
    "There is a version of you that wakes up early, does the work, stays consistent, and builds something worth being proud of. The only thing standing between you now and that version of you is a series of choices made in small moments. When you want to scroll, you choose to close the app. When you want to skip the hard task, you open it anyway and write the first sentence. When you want to quit, you do five more minutes. Those micro-decisions compound into an identity over time. You become someone who finishes things. Someone who follows through. Someone who can be trusted — starting with yourself. That version of you is not some distant fantasy. It is one decision away. Make it.",
  ]
};

const SPRINT_DURATIONS = { easy: 60, medium: 45, hard: 30 };
let typingStartTime = null, typingTarget = "", sprintInterval = null, sprintRemaining = 0, sprintDifficulty = "medium";

function initTypingGame(diff) {
  if (diff) sprintDifficulty = diff;
  const pool = TYPING_SENTENCES[sprintDifficulty];
  typingTarget = pickRandom(pool);
  typingStartTime = null;
  clearInterval(sprintInterval); sprintInterval = null;
  sprintRemaining = SPRINT_DURATIONS[sprintDifficulty];

  const targetEl = document.getElementById("typingTarget");
  const inputEl  = document.getElementById("typingInput");
  const resultEl = document.getElementById("typingResult");
  const retryBtn = document.getElementById("typingRetry");
  const timerEl  = document.getElementById("sprintTimer");
  if (!targetEl) return;

  targetEl.innerHTML = typingTarget.split("").map((ch, i) =>
    `<span class="tc" id="tc${i}">${ch === " " ? "&nbsp;" : ch}</span>`
  ).join("");

  if (inputEl)  { inputEl.value = ""; inputEl.disabled = false; inputEl.placeholder = "Start typing to begin the timer…"; inputEl.focus(); }
  if (resultEl) { resultEl.style.display = "none"; }
  if (retryBtn) retryBtn.style.display = "none";
  if (timerEl)  { timerEl.textContent = sprintRemaining + "s"; timerEl.className = "sprint-timer"; }

  // highlight active difficulty btn
  document.querySelectorAll(".sprint-diff-btn").forEach(b =>
    b.classList.toggle("active", b.dataset.diff === sprintDifficulty)
  );
}

function startSprintTimer() {
  if (sprintInterval) return; // already running
  const timerEl = document.getElementById("sprintTimer");
  sprintInterval = setInterval(() => {
    sprintRemaining--;
    if (timerEl) { timerEl.textContent = sprintRemaining + "s"; timerEl.className = "sprint-timer" + (sprintRemaining <= 10 ? " urgent" : ""); }
    if (sprintRemaining <= 0) {
      clearInterval(sprintInterval); sprintInterval = null;
      const inputEl = document.getElementById("typingInput");
      if (inputEl && !inputEl.disabled) {
        // time ran out — score with whatever they typed
        finishTypingGame(inputEl.value);
      }
    }
  }, 1000);
}

function finishTypingGame(val) {
  const inputEl = document.getElementById("typingInput");
  if (inputEl) inputEl.disabled = true;
  clearInterval(sprintInterval); sprintInterval = null;

  const elapsed = typingStartTime ? (Date.now() - typingStartTime) / 1000 / 60 : 0.001;
  const wordsTyped = val.trim().split(/\s+/).filter(w => w).length;
  const wpm = Math.round(wordsTyped / elapsed);
  let correct = 0;
  for (let i = 0; i < Math.min(val.length, typingTarget.length); i++) if (val[i] === typingTarget[i]) correct++;
  const acc = val.length > 0 ? Math.round((correct / Math.max(val.length, typingTarget.length)) * 100) : 0;

  document.getElementById("typingWPM").textContent = wpm;
  document.getElementById("typingAcc").textContent = acc + "%";
  let rating = "Keep practicing! 💪";
  if (wpm >= 80 && acc >= 95) rating = "Absolutely elite! 🔥";
  else if (wpm >= 60 && acc >= 90) rating = "Solid speed! ⚡";
  else if (wpm >= 40) rating = "Nice work! Keep going.";
  document.getElementById("typingRating").textContent = rating;
  const resultEl = document.getElementById("typingResult");
  if (resultEl) { resultEl.style.display = "flex"; animateIn(resultEl); }
  document.getElementById("typingRetry").style.display = "inline-flex";
  trackFunCount();
}

function handleTypingInput(e) {
  const val = e.target.value;
  if (!typingStartTime && val.length > 0) { typingStartTime = Date.now(); startSprintTimer(); }

  for (let i = 0; i < typingTarget.length; i++) {
    const span = document.getElementById(`tc${i}`);
    if (!span) continue;
    if (i < val.length) span.className = "tc " + (val[i] === typingTarget[i] ? "correct" : "wrong");
    else if (i === val.length) span.className = "tc cursor";
    else span.className = "tc";
  }

  if (val.length >= typingTarget.length) finishTypingGame(val);
}

// ── 2. Chess vs AI ───────────────────────────────────────────────────────────
// Piece symbols (white uppercase, black lowercase)
const PIECES = { K:'♔', Q:'♕', R:'♖', B:'♗', N:'♘', P:'♙', k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' };
const CHESS_DEPTH = { easy: 1, medium: 2, hard: 3 };
let chessBoard, chessTurn, chessSelected, chessLegalMoves, chessHistory, chessGameOver, chessDiff, chessTimerInt, chessTimeLeft, chessCapWhite, chessCapBlack;

function chessFreshBoard() {
  return [
    ['r','n','b','q','k','b','n','r'],
    ['p','p','p','p','p','p','p','p'],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    ['P','P','P','P','P','P','P','P'],
    ['R','N','B','Q','K','B','N','R']
  ];
}

function isWhite(p){ return p && p === p.toUpperCase(); }
function isBlack(p){ return p && p === p.toLowerCase(); }
function enemy(p, white){ return white ? isBlack(p) : isWhite(p); }
function friendly(p, white){ return white ? isWhite(p) : isBlack(p); }

function chessRawMoves(board, r, c, white) {
  const p = board[r][c]; const moves = [];
  const add = (nr, nc) => { if (nr>=0&&nr<8&&nc>=0&&nc<8&&!friendly(board[nr][nc],white)) moves.push([nr,nc]); };
  const slide = (dr, dc) => { let nr=r+dr,nc=c+dc; while(nr>=0&&nr<8&&nc>=0&&nc<8){ if(friendly(board[nr][nc],white)) break; moves.push([nr,nc]); if(board[nr][nc]) break; nr+=dr; nc+=dc; } };
  const pt = p.toUpperCase();
  if (pt==='P') {
    const dir = white ? -1 : 1; const start = white ? 6 : 1;
    if (!board[r+dir]?.[c]) { moves.push([r+dir,c]); if (r===start && !board[r+2*dir]?.[c]) moves.push([r+2*dir,c]); }
    [[r+dir,c-1],[r+dir,c+1]].forEach(([nr,nc])=>{ if(nr>=0&&nr<8&&nc>=0&&nc<8&&enemy(board[nr][nc],white)) moves.push([nr,nc]); });
  } else if (pt==='N') { [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]].forEach(([dr,dc])=>add(r+dr,c+dc)); }
  else if (pt==='B') { [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(([dr,dc])=>slide(dr,dc)); }
  else if (pt==='R') { [[-1,0],[1,0],[0,-1],[0,1]].forEach(([dr,dc])=>slide(dr,dc)); }
  else if (pt==='Q') { [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]].forEach(([dr,dc])=>slide(dr,dc)); }
  else if (pt==='K') { [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]].forEach(([dr,dc])=>add(r+dr,c+dc)); }
  return moves;
}

function cloneBoard(b){ return b.map(r=>[...r]); }

function inCheck(board, white) {
  let kr=-1,kc=-1;
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) if(board[r][c]===(white?'K':'k')){ kr=r;kc=c; }
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) { const p=board[r][c]; if(p&&enemy(p,white)) if(chessRawMoves(board,r,c,!white).some(([nr,nc])=>nr===kr&&nc===kc)) return true; }
  return false;
}

function legalMoves(board, r, c) {
  const p = board[r][c]; if (!p) return [];
  const white = isWhite(p);
  return chessRawMoves(board,r,c,white).filter(([nr,nc])=>{ const nb=cloneBoard(board); nb[nr][nc]=p; nb[r][c]=0; if(p==='P'&&nc!==c&&!board[nr][nc]) return false; return !inCheck(nb,white); });
}

function allLegalMoves(board, white) {
  const moves=[];
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) { const p=board[r][c]; if(p&&isWhite(p)===white) legalMoves(board,r,c).forEach(([nr,nc])=>moves.push([r,c,nr,nc])); }
  return moves;
}

function pieceValue(p) { const v={P:1,N:3,B:3,R:5,Q:9,K:0}; return v[p.toUpperCase()]||0; }

function evalBoard(board) {
  let score=0;
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) { const p=board[r][c]; if(p) score += (isWhite(p)?-1:1)*pieceValue(p); }
  return score;
}

function minimax(board, depth, alpha, beta, maximizing) {
  if (depth===0) return evalBoard(board);
  const moves = allLegalMoves(board, !maximizing); // black maximizes
  if (!moves.length) return inCheck(board,!maximizing) ? (maximizing?-999:999) : 0;
  if (maximizing) {
    let best=-Infinity;
    for(const [r,c,nr,nc] of moves){ const nb=cloneBoard(board); nb[nr][nc]=nb[r][c]; nb[r][c]=0; best=Math.max(best,minimax(nb,depth-1,alpha,beta,false)); alpha=Math.max(alpha,best); if(beta<=alpha) break; }
    return best;
  } else {
    let best=Infinity;
    for(const [r,c,nr,nc] of moves){ const nb=cloneBoard(board); nb[nr][nc]=nb[r][c]; nb[r][c]=0; best=Math.min(best,minimax(nb,depth-1,alpha,beta,true)); beta=Math.min(beta,best); if(beta<=alpha) break; }
    return best;
  }
}

function aiMove(board, depth) {
  const moves = allLegalMoves(board, false);
  if (!moves.length) return null;
  if (depth===1) return moves[Math.floor(Math.random()*Math.min(moves.length, 5+Math.random()*3|0))];
  let best=-Infinity, bestMove=null;
  for(const [r,c,nr,nc] of moves){ const nb=cloneBoard(board); nb[nr][nc]=nb[r][c]; nb[r][c]=0; const score=minimax(nb,depth-1,-Infinity,Infinity,false); if(score>best||(score===best&&Math.random()<0.2)){ best=score; bestMove=[r,c,nr,nc]; } }
  return bestMove;
}

function renderChessBoard() {
  const el = document.getElementById('chessBoard'); if(!el) return;
  el.innerHTML='';
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) {
    const cell = document.createElement('div');
    const isLight = (r+c)%2===0;
    cell.className = 'chess-cell '+(isLight?'light':'dark');
    cell.dataset.r=r; cell.dataset.c=c;
    const p = chessBoard[r][c];
    if(p) {
      cell.textContent = PIECES[p]||p;
      cell.classList.add(p === p.toUpperCase() ? 'piece-white' : 'piece-black');
    }
    if(chessSelected&&chessSelected[0]===r&&chessSelected[1]===c) cell.classList.add('selected');
    if(chessLegalMoves&&chessLegalMoves.some(([nr,nc])=>nr===r&&nc===c)) cell.classList.add('legal');
    if(chessHistory.length){ const last=chessHistory[chessHistory.length-1]; if((last.from[0]===r&&last.from[1]===c)||(last.to[0]===r&&last.to[1]===c)) cell.classList.add('last-move'); }
    if(inCheck(chessBoard,true)&&p==='K') cell.classList.add('in-check');
    if(inCheck(chessBoard,false)&&p==='k') cell.classList.add('in-check');
    cell.addEventListener('click',()=>onChessCellClick(r,c));
    el.appendChild(cell);
  }
  // Update captures
  const capW = chessCapWhite.map(p=>PIECES[p]||p).join('');
  const capB = chessCapBlack.map(p=>PIECES[p]||p).join('');
  const cwEl = document.getElementById('chessCapWhite'); if(cwEl) cwEl.textContent = capW ? '⬜ '+capW : '';
  const cbEl = document.getElementById('chessCapBlack'); if(cbEl) cbEl.textContent = capB ? '⬛ '+capB : '';
}

function onChessCellClick(r,c) {
  if(chessGameOver||chessTurn!=='white') return;
  const p = chessBoard[r][c];
  if(chessSelected){
    const [sr,sc]=chessSelected;
    const isLegal = chessLegalMoves.some(([nr,nc])=>nr===r&&nc===c);
    if(isLegal){
      chessHistory.push({from:[sr,sc],to:[r,c],board:cloneBoard(chessBoard)});
      const captured = chessBoard[r][c];
      if(captured) chessCapWhite.push(captured);
      chessBoard[r][c]=chessBoard[sr][sc]; chessBoard[sr][sc]=0;
      // Pawn promotion
      if(chessBoard[r][c]==='P'&&r===0) chessBoard[r][c]='Q';
      if(chessBoard[r][c]==='p'&&r===7) chessBoard[r][c]='q';
      chessSelected=null; chessLegalMoves=[];
      chessTurn='black';
      updateChessStatus();
      renderChessBoard();
      setTimeout(doAiMove,300);
      return;
    }
    chessSelected=null; chessLegalMoves=[];
  }
  if(p&&isWhite(p)){ chessSelected=[r,c]; chessLegalMoves=legalMoves(chessBoard,r,c); }
  renderChessBoard();
}

function doAiMove() {
  if(chessGameOver) return;
  const depth = CHESS_DEPTH[chessDiff]||2;
  const move = aiMove(chessBoard, depth);
  if(!move){ endChessGame('You win! 🏆','AI has no moves — checkmate or stalemate!'); return; }
  const [r,c,nr,nc]=move;
  chessHistory.push({from:[r,c],to:[nr,nc],board:cloneBoard(chessBoard)});
  const captured=chessBoard[nr][nc];
  if(captured) chessCapBlack.push(captured);
  chessBoard[nr][nc]=chessBoard[r][c]; chessBoard[r][c]=0;
  if(chessBoard[nr][nc]==='p'&&nr===7) chessBoard[nr][nc]='q';
  chessTurn='white';
  // Check game over
  const whiteMoves=allLegalMoves(chessBoard,true);
  if(!whiteMoves.length){ if(inCheck(chessBoard,true)) endChessGame('Checkmate 💀','The AI got you. Try again!'); else endChessGame('Stalemate 🤝','No legal moves — draw!'); return; }
  updateChessStatus();
  renderChessBoard();
}

function updateChessStatus() {
  const el=document.getElementById('chessStatus'); if(!el) return;
  if(chessTurn==='white'){
    el.textContent = inCheck(chessBoard,true) ? '⚠️ You are in check!' : 'Your turn (White)';
    el.style.color = inCheck(chessBoard,true) ? '#f97316' : 'var(--accent)';
  } else {
    el.textContent = 'AI is thinking…';
    el.style.color = 'var(--muted)';
  }
}

function startChessTimer() {
  clearInterval(chessTimerInt);
  chessTimeLeft = 600; // 10 mins
  const el = document.getElementById('chessTimer');
  chessTimerInt = setInterval(()=>{
    chessTimeLeft--;
    if(el){ const m=Math.floor(chessTimeLeft/60),s=chessTimeLeft%60; el.textContent=`${m}:${String(s).padStart(2,'0')}`; el.className='sprint-timer'+(chessTimeLeft<=60?' urgent':''); }
    if(chessTimeLeft<=0){ clearInterval(chessTimerInt); endChessGame("Time's up! ⏰","You ran out of time."); }
  },1000);
}

function endChessGame(msg, sub) {
  chessGameOver=true; clearInterval(chessTimerInt);
  document.getElementById('chessGame').style.display='none';
  const endEl=document.getElementById('chessEnd'); endEl.style.display='flex';
  document.getElementById('chessEndMsg').textContent=msg;
  document.getElementById('chessEndSub').textContent=sub;
  document.getElementById('chessEndIcon').textContent=msg.includes('win')?'🏆':msg.includes('Time')?'⏰':'💀';
  if(msg.includes('win')) trackFunCount();
}

function initChessGame(diff) {
  chessDiff = diff || chessDiff || 'medium';
  chessBoard=chessFreshBoard(); chessTurn='white'; chessSelected=null; chessLegalMoves=[]; chessHistory=[]; chessGameOver=false; chessCapWhite=[]; chessCapBlack=[];
  document.querySelectorAll('.chess-diff').forEach(b=>b.classList.toggle('active',b.dataset.diff===chessDiff));
  const desc={easy:'AI plays randomly — great for beginners',medium:'Balanced AI — makes occasional mistakes',hard:'Strong AI — will punish every mistake'};
  const d=document.getElementById('chessDiffDesc'); if(d) d.textContent=desc[chessDiff];
}

function startChessGame() {
  document.getElementById('chessStart').style.display='none';
  document.getElementById('chessGame').style.display='flex';
  document.getElementById('chessEnd').style.display='none';
  startChessTimer(); renderChessBoard(); updateChessStatus();
}

function resetChessGame() {
  clearInterval(chessTimerInt);
  initChessGame(chessDiff);
  document.getElementById('chessStart').style.display='flex';
  document.getElementById('chessGame').style.display='none';
  document.getElementById('chessEnd').style.display='none';
}


// ── 3. Memory Match ───────────────────────────────────────────────────────────
const MEM_EMOJIS = ["🎯","⚡","🧠","🔥","💡","🏆","🎲","🌟"];
let memCards=[], memFlipped=[], memMatched=[], memMoves=0, memLocked=false, memStart=null;
let memCountdown=null, memTimeLeft=60, memTimerRunning=false;

function initMemoryGame() {
  const pool = shuffle([...MEM_EMOJIS, ...MEM_EMOJIS]);
  memCards = pool; memFlipped = []; memMatched = []; memMoves = 0; memLocked = false; memStart = null;
  clearInterval(memCountdown); memCountdown = null; memTimeLeft = 60; memTimerRunning = false;

  const container = document.getElementById("memoryGrid");
  if (!container) return;
  container.innerHTML = "";
  document.getElementById("memoryMoves").textContent = "0";
  const resultEl = document.getElementById("memoryResult");
  if (resultEl) resultEl.style.display = "none";

  // Reset countdown display
  const timerEl = document.getElementById("memCountdownEl");
  if (timerEl) { timerEl.textContent = "60s"; timerEl.className = "mem-countdown"; }

  pool.forEach((emoji, i) => {
    const card = document.createElement("div");
    card.className = "mem-card";
    card.dataset.index = i;
    card.innerHTML = `<div class="mem-front">?</div><div class="mem-back">${emoji}</div>`;
    card.addEventListener("click", () => flipMemCard(i, emoji));
    container.appendChild(card);
  });
}

function startMemCountdown() {
  if (memTimerRunning) return;
  memTimerRunning = true;
  memCountdown = setInterval(() => {
    memTimeLeft--;
    const timerEl = document.getElementById("memCountdownEl");
    if (timerEl) { timerEl.textContent = memTimeLeft + "s"; timerEl.className = "mem-countdown" + (memTimeLeft <= 10 ? " urgent" : ""); }
    if (memTimeLeft <= 0) {
      clearInterval(memCountdown); memCountdown = null;
      // Time's up — show result with whatever time
      if (memMatched.length < memCards.length) {
        showMemResult("60", true);
      }
    }
  }, 1000);
}

function flipMemCard(idx, emoji) {
  if (memLocked || memFlipped.includes(idx) || memMatched.includes(idx)) return;
  if (!memStart) { memStart = Date.now(); startMemCountdown(); }
  const card = document.querySelector(`.mem-card[data-index="${idx}"]`);
  if (card) card.classList.add("flipped");
  memFlipped.push(idx);

  if (memFlipped.length === 2) {
    memMoves++;
    document.getElementById("memoryMoves").textContent = memMoves;
    memLocked = true;
    const [a, b] = memFlipped;
    if (memCards[a] === memCards[b]) {
      memMatched.push(a, b);
      document.querySelector(`.mem-card[data-index="${a}"]`)?.classList.add("matched");
      document.querySelector(`.mem-card[data-index="${b}"]`)?.classList.add("matched");
      memFlipped = []; memLocked = false;
      if (memMatched.length === memCards.length) {
        clearInterval(memCountdown);
        const elapsed = ((Date.now() - memStart)/1000).toFixed(1);
        setTimeout(() => showMemResult(elapsed, false), 400);
      }
    } else {
      setTimeout(() => {
        document.querySelector(`.mem-card[data-index="${a}"]`)?.classList.remove("flipped");
        document.querySelector(`.mem-card[data-index="${b}"]`)?.classList.remove("flipped");
        memFlipped = []; memLocked = false;
      }, 900);
    }
  }
}

function showMemResult(elapsed, timeUp) {
  const r = document.getElementById("memoryResult");
  document.getElementById("memoryTime").textContent = timeUp ? "⏰ Time up!" : elapsed + "s";
  document.getElementById("memoryMovFinal").textContent = memMoves;
  let rating = "Nice work! 🧠";
  if (timeUp) rating = "So close! Try again 💪";
  else if (memMoves <= 10) rating = "Memory beast! 🏆";
  else if (memMoves <= 14) rating = "Sharp mind! 🌟";
  else if (memMoves <= 18) rating = "Solid! 🎯";
  document.getElementById("memoryRating").textContent = rating;
  if (r) { r.style.display = "block"; animateIn(r); }
  if (!timeUp) trackFunCount();
}

// ── 4. Focus Quiz ─────────────────────────────────────────────────────────────
const QUIZ_Q = [
  { q: "What does the Pomodoro Technique recommend as the standard focus interval?", opts: ["15 min","20 min","25 min","45 min"], ans: 2 },
  { q: "On average, how long does it take to regain full focus after an interruption?", opts: ["2 min","5 min","23 min","1 hour"], ans: 2 },
  { q: "What's the biggest predictor of entering a 'flow state'?", opts: ["High skill + low challenge","Low skill + high challenge","Balanced skill + challenge","Complete silence"], ans: 2 },
  { q: "Which background noise is often studied to boost concentration?", opts: ["Pop music with lyrics","Brown/white noise","Complete silence","Office chatter"], ans: 1 },
  { q: "How many items can working memory typically hold at once?", opts: ["3–5","7 ± 2","10–12","20+"], ans: 1 },
  { q: "According to Cal Newport, 'deep work' is best described as:", opts: ["Multitasking on complex tasks","Focused, uninterrupted cognitively demanding work","Working longer hours","Working in silence only"], ans: 1 },
  { q: "What is 'time-blocking'?", opts: ["Blocking distracting websites","Scheduling specific time slots for tasks","Limiting work to set hours","Setting timers for breaks"], ans: 1 },
  { q: "The 2-minute rule says: if a task takes less than 2 minutes, you should…", opts: ["Schedule it for later","Delegate it","Do it immediately","Write it down first"], ans: 2 },
  { q: "Which study habit is most consistently linked to high long-term performance?", opts: ["Cramming before exams","Spaced repetition","Re-reading notes","Highlighting textbooks"], ans: 1 },
  { q: "What does 'eat the frog' mean in productivity?", opts: ["Take a big lunch break","Tackle the hardest task first","Avoid unpleasant tasks","Reward yourself with food"], ans: 1 },
  { q: "The Zeigarnik Effect says we remember uncompleted tasks better. How do you apply this?", opts: ["Always finish completely","Leave tasks slightly open to stay motivated","Avoid starting tasks you can't finish","Take more breaks"], ans: 1 },
  { q: "What is 'task batching'?", opts: ["Doing tasks alphabetically","Grouping similar tasks to reduce context switching","Breaking tasks into sub-tasks","Assigning tasks to others"], ans: 1 },
  { q: "What does GTD stand for in productivity?", opts: ["Get Things Done","Goals, Tasks, Deadlines","Growth Through Discipline","Getting Things Done"], ans: 3 },
  { q: "Which of these is NOT a symptom of decision fatigue?", opts: ["Impulsive choices","Avoiding decisions","Making worse decisions later in the day","Improved focus"], ans: 3 },
  { q: "What is the 'Eisenhower Matrix' used for?", opts: ["Tracking time","Prioritizing tasks by urgency and importance","Estimating project costs","Scheduling meetings"], ans: 1 },
  { q: "How long does it typically take to form a new habit?", opts: ["7 days","21 days","66 days","6 months"], ans: 2 },
  { q: "What is 'context switching' in productivity?", opts: ["Changing your work environment","Shifting between different tasks repeatedly","Switching between apps","Working across time zones"], ans: 1 },
  { q: "Which sleep duration is most recommended for peak cognitive performance?", opts: ["5–6 hours","7–9 hours","10–11 hours","4 hours"], ans: 1 },
  { q: "What is the '1-3-5 rule'?", opts: ["Work 1 hour, break 3 min, repeat 5x","Accomplish 1 big, 3 medium, 5 small tasks daily","Set 1 goal, 3 steps, 5 actions","Work for 1h, 3h, 5h blocks"], ans: 1 },
  { q: "What does 'inbox zero' mean?", opts: ["Getting zero emails","Keeping your email inbox empty or near empty","Deleting all old emails","Having zero unread messages"], ans: 1 },
  { q: "Which technique involves writing tasks by hand to better remember them?", opts: ["Digital logging","Bullet journaling","Mind mapping","Kanban"], ans: 1 },
  { q: "What is 'mono-tasking'?", opts: ["Working alone","Focusing on one task at a time","Using one app only","Completing tasks in one sitting"], ans: 1 },
  { q: "What is the recommended break after each Pomodoro session?", opts: ["1 minute","5 minutes","15 minutes","30 minutes"], ans: 1 },
  { q: "Which hormone is most associated with stress and reduced focus?", opts: ["Dopamine","Serotonin","Cortisol","Melatonin"], ans: 2 },
  { q: "What is 'temptation bundling'?", opts: ["Saving rewards for later","Pairing enjoyable activities with tasks you avoid","Bundling all tasks together","Rewarding yourself after completing tasks"], ans: 1 },
  { q: "Which of these improves focus according to research?", opts: ["Checking phone every 10 min","Cold water exposure","Multitasking","Skipping breakfast"], ans: 1 },
  { q: "What does 'deep work' require that 'shallow work' does not?", opts: ["More tools","Undistracted intense concentration","A team","Longer hours"], ans: 1 },
  { q: "What is the primary purpose of a 'weekly review' in GTD?", opts: ["Reviewing your week socially","Processing and organizing all tasks and commitments","Measuring productivity metrics","Planning next month"], ans: 1 },
  { q: "What is 'proactive vs reactive' work?", opts: ["Planning ahead vs responding to what comes in","Working fast vs slow","Team work vs solo work","Morning work vs evening work"], ans: 0 },
  { q: "Which environment change is shown to most boost focus?", opts: ["Bright lights","Eliminating digital notifications","Playing loud music","Sitting at a standing desk"], ans: 1 },
  { q: "What does the 80/20 rule (Pareto Principle) suggest about productivity?", opts: ["80% of results come from 80% of effort","20% of tasks produce 80% of results","Work 80% of the time","Take 20% more breaks"], ans: 1 },
  { q: "What is 'proactive rest'?", opts: ["Sleeping more","Intentionally scheduling recovery time","Resting only when tired","Taking unplanned breaks"], ans: 1 },
];

let quizQs=[], quizIdx=0, quizScore=0, quizAnswered=false, quizTimerInt=null, quizTimeLeft=0;
const QUIZ_TIME_PER_Q = 20; // seconds per question

function initQuiz() {
  quizQs = shuffle(QUIZ_Q).slice(0, 10);
  quizIdx = 0; quizScore = 0;
  clearInterval(quizTimerInt);
  document.getElementById("quizResult").style.display = "none";
  renderQuizQ();
}

function startQuizTimer() {
  clearInterval(quizTimerInt);
  quizTimeLeft = QUIZ_TIME_PER_Q;
  const el = document.getElementById("quizTimerBar");
  const numEl = document.getElementById("quizTimerNum");
  if (el) el.style.width = "100%";
  if (numEl) numEl.textContent = quizTimeLeft + "s";
  quizTimerInt = setInterval(() => {
    quizTimeLeft--;
    const pct = (quizTimeLeft / QUIZ_TIME_PER_Q) * 100;
    if (el) { el.style.width = pct + "%"; el.style.background = quizTimeLeft <= 5 ? "#f97316" : "#38bdf8"; }
    if (numEl) { numEl.textContent = quizTimeLeft + "s"; numEl.style.color = quizTimeLeft <= 5 ? "#f97316" : "var(--muted)"; }
    if (quizTimeLeft <= 0) {
      clearInterval(quizTimerInt);
      if (!quizAnswered) {
        quizAnswered = true;
        document.querySelectorAll(".quiz-opt").forEach((b, j) => {
          b.disabled = true;
          if (j === quizQs[quizIdx].ans) b.classList.add("correct");
        });
        const fb = document.getElementById("quizFB");
        if (fb) { fb.textContent = "⏰ Time's up! Answer: " + quizQs[quizIdx].opts[quizQs[quizIdx].ans]; fb.className = "quiz-feedback wrong"; }
        setTimeout(() => { quizIdx++; renderQuizQ(); }, 1500);
      }
    }
  }, 1000);
}

function renderQuizQ() {
  clearInterval(quizTimerInt);
  const container = document.getElementById("quizContainer");
  if (quizIdx >= quizQs.length) { showQuizResult(); return; }
  const q = quizQs[quizIdx];
  quizAnswered = false;
  const pct = (quizIdx / quizQs.length) * 100;
  container.innerHTML = `
    <div class="quiz-progress-bar"><div class="quiz-progress-fill" style="width:${pct}%"></div></div>
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.5rem;">
      <div class="quiz-counter">${quizIdx+1} / ${quizQs.length}</div>
      <div style="display:flex;align-items:center;gap:0.4rem;">
        <div style="width:80px;height:5px;background:rgba(148,163,184,0.2);border-radius:999px;overflow:hidden;"><div id="quizTimerBar" style="height:100%;background:#38bdf8;transition:width 0.9s linear;border-radius:999px;"></div></div>
        <span id="quizTimerNum" style="font-size:0.72rem;color:var(--muted);font-weight:600;font-variant-numeric:tabular-nums;">20s</span>
      </div>
    </div>
    <div class="quiz-question">${q.q}</div>
    <div class="quiz-options">${q.opts.map((o,i)=>`<button class="quiz-opt" data-i="${i}">${o}</button>`).join("")}</div>
    <div class="quiz-feedback" id="quizFB"></div>
  `;
  document.querySelectorAll(".quiz-opt").forEach(btn => {
    btn.addEventListener("click", () => {
      if (quizAnswered) return;
      quizAnswered = true;
      clearInterval(quizTimerInt);
      const i = parseInt(btn.dataset.i);
      if (i === q.ans) quizScore++;
      document.querySelectorAll(".quiz-opt").forEach((b,j) => {
        b.disabled = true;
        if (j === q.ans) b.classList.add("correct");
        else if (j === i) b.classList.add("wrong");
      });
      const fb = document.getElementById("quizFB");
      if (fb) { fb.textContent = i===q.ans ? "✓ Correct!" : `✗ Answer: ${q.opts[q.ans]}`; fb.className = "quiz-feedback "+(i===q.ans?"correct":"wrong"); }
      setTimeout(() => { quizIdx++; renderQuizQ(); }, 1500);
    });
  });
  animateIn(container);
  startQuizTimer();
}

function showQuizResult() {
  clearInterval(quizTimerInt);
  const r = document.getElementById("quizResult");
  const pct = Math.round((quizScore/quizQs.length)*100);
  let rating = "Keep learning! 📖";
  if (pct >= 90) rating = "Productivity guru! 🏆";
  else if (pct >= 70) rating = "Solid knowledge! 🌟";
  else if (pct >= 50) rating = "Getting there! 💪";
  r.innerHTML = `<div class="quiz-final-score">${quizScore}/${quizQs.length}</div><div class="quiz-final-pct">${pct}% correct</div><div class="quiz-rating">${rating}</div><button class="game-btn" id="quizRetry">🔄 Play Again</button>`;
  r.style.display = "flex"; animateIn(r);
  document.getElementById("quizRetry")?.addEventListener("click", initQuiz);
  if (pct >= 70) trackFunCount();
}

// ── Tab switching ─────────────────────────────────────────────────────────────
let tabInited = {};
function switchTab(tab) {
  document.querySelectorAll(".fun-tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  document.querySelectorAll(".fun-panel").forEach(p => p.style.display = p.dataset.panel === tab ? "block" : "none");
  if (tab === "typing") initTypingGame();
  if (tab === "memory") initMemoryGame();
  if (tab === "quiz") { if (!tabInited[tab]) initQuiz(); }
  if (tab === "math") { initChessGame(chessDiff); }
  tabInited[tab] = true;
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  console.log("CLOCKED IN V10 NEW VERSION LOADED ✅");
  document.querySelectorAll(".fun-tab-btn").forEach(btn => btn.addEventListener("click", () => switchTab(btn.dataset.tab)));

  // Truth & Dare
  document.getElementById("truthBtn")?.addEventListener("click", () => showChallenge("truth"));
  document.getElementById("dareBtn")?.addEventListener("click", () => showChallenge("dare"));
  document.getElementById("againBtn")?.addEventListener("click", resetTDToButtons);
  document.getElementById("timerPauseBtn")?.addEventListener("click", () => { timerRunning = !timerRunning; renderTimer(); });
  document.getElementById("submitAnswerBtn")?.addEventListener("click", () => {
    const val = document.getElementById("answerInput")?.value.trim();
    if (val && currentChallenge) getAIResponse(currentChallenge.text, val, currentChallenge.type);
  });
  document.getElementById("answerInput")?.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); document.getElementById("submitAnswerBtn")?.click(); }
  });

  // Typing
  document.getElementById("typingInput")?.addEventListener("input", handleTypingInput);
  document.getElementById("typingRetry")?.addEventListener("click", () => initTypingGame());
  document.querySelectorAll(".sprint-diff-btn").forEach(btn => {
    btn.addEventListener("click", () => initTypingGame(btn.dataset.diff));
  });

  // Chess
  document.getElementById("chessStartBtn")?.addEventListener("click", startChessGame);
  document.getElementById("chessRetryBtn")?.addEventListener("click", resetChessGame);
  document.getElementById("chessResignBtn")?.addEventListener("click", ()=>endChessGame("You resigned 🏳️","Better luck next time!"));
  document.getElementById("chessUndoBtn")?.addEventListener("click", ()=>{
    if(chessHistory.length<2||chessTurn!=='white') return;
    chessHistory.pop(); chessHistory.pop(); // undo player + AI move
    const last=chessHistory[chessHistory.length-1];
    chessBoard=last?cloneBoard(last.board):chessFreshBoard();
    chessCapWhite=[]; chessCapBlack=[]; chessTurn='white'; chessSelected=null; chessLegalMoves=[];
    updateChessStatus(); renderChessBoard();
  });
  document.querySelectorAll(".chess-diff").forEach(btn=>{
    btn.addEventListener("click", ()=>initChessGame(btn.dataset.diff));
  });

  // Memory
  document.getElementById("memoryRetry")?.addEventListener("click", initMemoryGame);

  // Stats
  chrome.storage.local.get({ browsingSeconds: 0, browsingDate: "" }, (data) => {
    const today = todayKey();
    const secs = data.browsingDate === today ? data.browsingSeconds : 0;
    const el = document.getElementById("browsingTime");
    if (el) el.textContent = formatDuration(secs);
  });
  chrome.storage.sync.get({ funCount: 0, funDate: "" }, (data) => {
    const today = todayKey();
    const el = document.getElementById("funCount");
    if (el) el.textContent = data.funDate === today ? data.funCount : 0;
  });

  // Origin
  const params = new URLSearchParams(window.location.search);
  const from = params.get("from");
  if (from) {
    try {
      const hostname = new URL(from).hostname.replace("www.","");
      const note = document.getElementById("originSite");
      if (note) note.textContent = `You were heading to ${hostname} — let's do something fun instead!`;
    } catch(_) {}
  }

  switchTab("td");
});
