const BADGE_MAP = {
  first_block:   "🛡️",
  focus_starter: "🎯",
  deep_work:     "🧠",
  flow_state:    "⚡",
  iron_will:     "🏰",
  no_scroll:     "🚫",
  truth_seeker:  "💬",
  dare_devil:    "🌶️",
  game_master:   "🎲",
  laugh_riot:    "😂",
  two_day:       "📅",
  one_week:      "🔥",
  two_weeks:     "🌟",
  monthly:       "🏅",
  night_owl:     "🦉",
  early_bird:    "🌅",
  digital_zen:   "🌙",
  wiki_wanderer: "📚",
  golden_clock:  "🏆",
};

const DEFAULT_BLOCKED_SITES = [
  "facebook.com","instagram.com","tiktok.com","twitter.com","x.com",
  "reddit.com","youtube.com","netflix.com","twitch.tv","pinterest.com",
  "snapchat.com","tumblr.com","discord.com","9gag.com","buzzfeed.com","imgur.com"
];
const DEFAULT_REDIRECT_URL = "https://www.wikipedia.org/";
const DEFAULT_BLOCKED_KEYWORDS = [];  // empty by default — user opts in
const DEFAULT_SCHEDULE = {
  enabled: false,
  days: [1,2,3,4,5],
  startHour: 9, startMin: 0,
  endHour: 18,  endMin: 0
};
const DEFAULT_AVATAR = "🧑‍💻";
const DEFAULT_NAME = "You";

const AVATAR_OPTIONS = [
  "🧑‍💻","👩‍💻","👨‍💻","🧑‍🎨","👩‍🎨","👨‍🎨","🧑‍🔬","👩‍🔬","👨‍🔬",
  "🧑‍🎓","👩‍🎓","👨‍🎓","🧑‍🏫","👩‍🏫","👨‍🏫","🧑‍💼","👩‍💼","👨‍💼",
  "🦊","🐺","🐯","🦁","🐻","🐼","🦄","🐉","🦅","🐙","🦋","🌟"
];

function $(id) { return document.getElementById(id); }

function showStatus(message, type = "ok") {
  const el = $("status");
  el.textContent = message;
  el.classList.remove("ok","error");
  if (message) el.classList.add(type);
}

// ── Avatar picker ─────────────────────────────────────────────────────────────
let selectedAvatar = DEFAULT_AVATAR;

function buildAvatarGrid(current) {
  const grid = $("avatarGrid");
  grid.innerHTML = "";
  AVATAR_OPTIONS.forEach(emoji => {
    const btn = document.createElement("button");
    btn.className = "avatar-opt" + (emoji === current ? " selected" : "");
    btn.textContent = emoji;
    btn.type = "button";
    btn.addEventListener("click", () => {
      document.querySelectorAll(".avatar-opt").forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      selectedAvatar = emoji;
      updatePreview();
    });
    grid.appendChild(btn);
  });
}

function updatePreview() {
  const name = $("displayName").value.trim() || DEFAULT_NAME;
  $("previewAvatar").textContent = selectedAvatar;
  $("previewName").textContent = name;
}

// ── Load ──────────────────────────────────────────────────────────────────────
function loadOptions() {
  chrome.storage.sync.get({
    blockedSites: DEFAULT_BLOCKED_SITES,
    redirectUrl: DEFAULT_REDIRECT_URL,
    blockedKeywords: DEFAULT_BLOCKED_KEYWORDS,
    allowedPages: [],
    schedule: DEFAULT_SCHEDULE,
    displayName: DEFAULT_NAME,
    avatar: DEFAULT_AVATAR,
    ownedBadges: []
  }, (items) => {
    $("blockedSites").value = (items.blockedSites || DEFAULT_BLOCKED_SITES).join("\n");
    $("redirectUrl").value = items.redirectUrl || DEFAULT_REDIRECT_URL;
    const kw = items.blockedKeywords;
    $("blockedKeywords").value = Array.isArray(kw) ? kw.join("\n") : typeof kw === "string" ? kw : DEFAULT_BLOCKED_KEYWORDS.join("\n");
    const ap = items.allowedPages;
    $("allowedPages").value = Array.isArray(ap) ? ap.join("\n") : "";

    // Load schedule
    const sc = items.schedule || DEFAULT_SCHEDULE;
    $("scheduleEnabled").checked = !!sc.enabled;
    toggleScheduleUI(!!sc.enabled);
    $("startHour").value   = String(sc.startHour  ?? 9).padStart(2,"0");
    $("startMin").value    = String(sc.startMin   ?? 0).padStart(2,"0");
    $("endHour").value     = String(sc.endHour    ?? 18).padStart(2,"0");
    $("endMin").value      = String(sc.endMin     ?? 0).padStart(2,"0");
    // Set day checkboxes
    const days = Array.isArray(sc.days) ? sc.days : [1,2,3,4,5];
    document.querySelectorAll(".day-check").forEach(cb => {
      cb.checked = days.includes(Number(cb.value));
    });

    // Profile
    $("displayName").value = items.displayName || "";
    selectedAvatar = items.avatar || DEFAULT_AVATAR;
    buildAvatarGrid(selectedAvatar);
    updatePreview();

    // Show owned badges in preview
    const badgesEl = $("previewBadges");
    if (badgesEl) {
      badgesEl.innerHTML = (items.ownedBadges || []).slice(0,5).map(id => `<span class="preview-badge">${BADGE_MAP[id] || id}</span>`).join("");
    }
  });
}

// ── Save ──────────────────────────────────────────────────────────────────────
function saveOptions() {
  const blockedRaw = $("blockedSites").value.split("\n").map(s=>s.trim()).filter(s=>s.length>0);
  const blockedKeywordsRaw = $("blockedKeywords").value.split("\n").map(s=>s.trim()).filter(s=>s.length>0);
  const allowedPagesRaw = $("allowedPages").value.split("\n").map(s=>s.trim()).filter(s=>s.length>0);

  const scheduleEnabled = $("scheduleEnabled").checked;
  const selectedDays = [...document.querySelectorAll(".day-check:checked")].map(cb => Number(cb.value));
  const schedule = {
    enabled: scheduleEnabled,
    days: selectedDays,
    startHour: parseInt($("startHour").value) || 9,
    startMin:  parseInt($("startMin").value)  || 0,
    endHour:   parseInt($("endHour").value)   || 18,
    endMin:    parseInt($("endMin").value)    || 0,
  };
  const redirectUrl = $("redirectUrl").value.trim();
  const displayName = $("displayName").value.trim() || DEFAULT_NAME;

  try {
    if (!redirectUrl) { showStatus("Redirect URL cannot be empty.","error"); return; }
    new URL(redirectUrl);
  } catch(e) {
    showStatus("Redirect URL must be a valid URL (including https://).","error");
    return;
  }

  chrome.storage.sync.set({
    blockedSites: blockedRaw,
    blockedKeywords: blockedKeywordsRaw,
    allowedPages: allowedPagesRaw,
    schedule,
    redirectUrl,
    displayName,
    avatar: selectedAvatar
  }, () => {
    showStatus("Settings saved. Changes are now active.","ok");
    setTimeout(() => showStatus(""), 3000);
    updatePreview();
  });
}

function resetDefaults() {
  $("blockedSites").value = DEFAULT_BLOCKED_SITES.join("\n");
  $("redirectUrl").value = DEFAULT_REDIRECT_URL;
  $("blockedKeywords").value = DEFAULT_BLOCKED_KEYWORDS.join("\n");
  $("allowedPages").value = "";
  $("scheduleEnabled").checked = false;
  toggleScheduleUI(false);
  document.querySelectorAll(".day-check").forEach(cb => { cb.checked = [1,2,3,4,5].includes(Number(cb.value)); });
  $("startHour").value = "09"; $("startMin").value = "00";
  $("endHour").value   = "18"; $("endMin").value   = "00";
  saveOptions();
}

// Nuclear option — wipes ALL blocking-related keys from storage and writes
// a completely fresh set. Fixes stale/corrupted data from old versions.
function clearAndReset() {
  if (!confirm("This will wipe your blocked sites, keywords, allowed pages and schedule and reset them to defaults. Your profile, badges and points are NOT affected. Continue?")) return;

  // Remove all the keys that could be stale
  chrome.storage.sync.remove(["blockedSites","blockedKeywords","allowedPages","schedule","redirectUrl"], () => {
    // Now write clean fresh defaults
    chrome.storage.sync.set({
      blockedSites: DEFAULT_BLOCKED_SITES,
      blockedKeywords: [],
      allowedPages: [],
      redirectUrl: DEFAULT_REDIRECT_URL,
      schedule: DEFAULT_SCHEDULE
    }, () => {
      showStatus("✅ Storage cleared and reset to defaults!", "ok");
      setTimeout(() => loadOptions(), 500);
    });
  });
}

function toggleScheduleUI(enabled) {
  const panel = $("schedulePanel");
  if (panel) panel.style.opacity = enabled ? "1" : "0.4";
  document.querySelectorAll(".schedule-input").forEach(el => { el.disabled = !enabled; });
}

document.addEventListener("DOMContentLoaded", () => {
  loadOptions();

  $("displayName").addEventListener("input", updatePreview);

  $("scheduleEnabled").addEventListener("change", (e) => toggleScheduleUI(e.target.checked));

  $("save").addEventListener("click", (e) => { e.preventDefault(); saveOptions(); });
  $("reset").addEventListener("click", (e) => { e.preventDefault(); resetDefaults(); });
  const clearBtn = $("clearStorage");
  if (clearBtn) clearBtn.addEventListener("click", (e) => { e.preventDefault(); clearAndReset(); });
});

// ── Account ID backup/restore ─────────────────────────────────────────────────
function showIdStatus(msg, type) {
  const el = document.getElementById("idStatus");
  el.textContent = msg;
  el.classList.remove("ok","error");
  if (type) el.classList.add(type);
  setTimeout(() => { el.textContent = ""; el.classList.remove("ok","error"); }, 3000);
}

function loadUserId() {
  chrome.storage.local.get({ clockedInUserId: "" }, (data) => {
    if (data.clockedInUserId) {
      document.getElementById("userIdDisplay").value = data.clockedInUserId;
    } else {
      // Generate one if missing
      const id = "user_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      chrome.storage.local.set({ clockedInUserId: id }, () => {
        document.getElementById("userIdDisplay").value = id;
      });
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadUserId();

  document.getElementById("copyIdBtn").addEventListener("click", () => {
    const val = document.getElementById("userIdDisplay").value;
    if (!val) return;
    navigator.clipboard.writeText(val).then(() => {
      showIdStatus("✅ ID copied to clipboard — save it somewhere safe!", "ok");
    });
  });

  document.getElementById("importIdBtn").addEventListener("click", () => {
    const input = prompt("Paste your saved Clocked In user ID:");
    if (!input || !input.trim().startsWith("user_")) {
      showIdStatus("❌ Invalid ID — must start with 'user_'", "error");
      return;
    }
    const id = input.trim();
    chrome.storage.local.set({ clockedInUserId: id }, () => {
      document.getElementById("userIdDisplay").value = id;
      showIdStatus("✅ ID restored! Your leaderboard rank is back.", "ok");
    });
  });
});
