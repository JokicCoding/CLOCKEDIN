/**
 * popup.js — Clocked In v4
 * Browser popup: stats, daily challenge, share card, referral, XP animations
 */

const BADGE_MAP = {
  first_block:"🛡️", focus_starter:"🎯", deep_work:"🧠", flow_state:"⚡",
  iron_will:"🏰", no_scroll:"🚫", truth_seeker:"💬", dare_devil:"🌶️",
  game_master:"🎲", laugh_riot:"😂", two_day:"📅", one_week:"🔥",
  two_weeks:"🌟", monthly:"🏅", night_owl:"🦉", early_bird:"🌅",
  digital_zen:"🌙", wiki_wanderer:"📚", golden_clock:"🏆", recruiter:"🤝"
};

// ── Daily challenge (seeded by date so everyone gets the same one) ─────────────
const DAILY_POOL = [
  { type:"truth", text:"What's one thing you'd do differently if you had no fear of failure?" },
  { type:"dare",  text:"Text someone you haven't talked to in a while just to say hi — right now!" },
  { type:"truth", text:"What is your most unpopular opinion about something everyone else loves?" },
  { type:"dare",  text:"Set a 10-minute focus timer and get one thing done before checking your phone." },
  { type:"truth", text:"What habit are you most trying to build right now and why?" },
  { type:"dare",  text:"Do 20 jumping jacks before you open any social media today." },
  { type:"truth", text:"What is the last thing you learned that genuinely surprised you?" },
  { type:"dare",  text:"Write down 3 things you are grateful for before doing anything else today." },
  { type:"truth", text:"What would you do with your time if screens didn't exist?" },
  { type:"dare",  text:"Drink a full glass of water right now. Go!" },
  { type:"truth", text:"What is something you keep putting off that you know you should do?" },
  { type:"dare",  text:"Close every browser tab you don't need right now. Be ruthless." },
  { type:"truth", text:"What does your ideal productive day look like?" },
  { type:"dare",  text:"Stand up and stretch for 60 seconds before continuing." },
  { type:"truth", text:"What app or website do you wish you used less and why?" },
  { type:"dare",  text:"Put your phone in another room for the next 30 minutes." },
  { type:"truth", text:"What is one small win you had this week?" },
  { type:"dare",  text:"Write one sentence about what you want to accomplish today." },
  { type:"truth", text:"When do you feel most focused and in the zone?" },
  { type:"dare",  text:"Reply to one message you've been avoiding. Do it now!" },
  { type:"truth", text:"What is your biggest digital distraction and what triggers it?" },
  { type:"dare",  text:"Take 5 deep breaths. Slow and deliberate. Right now." },
  { type:"truth", text:"If you could only use 3 apps for a week, which would you pick?" },
  { type:"dare",  text:"Tidy your desk or workspace before starting your next task." },
  { type:"truth", text:"What goal have you been secretly working toward?" },
  { type:"dare",  text:"Write down tomorrow's top 3 priorities before you sleep tonight." },
  { type:"truth", text:"What is one thing that always kills your focus?" },
  { type:"dare",  text:"Go outside and take 10 breaths of fresh air right now." },
  { type:"truth", text:"What would you work on if you had 2 completely free hours today?" },
  { type:"dare",  text:"Send an encouraging message to someone on your team or in your life." },
];

function getDailyChallenge() {
  const d = new Date();
  const seed = d.getFullYear() * 10000 + (d.getMonth()+1) * 100 + d.getDate();
  return DAILY_POOL[seed % DAILY_POOL.length];
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function formatDuration(s) {
  s = Math.max(0, Math.floor(Number(s)||0));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s/60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m/60), r = m%60;
  return r===0 ? `${h}h` : `${h}h ${r}m`;
}

function computeScore(rescuedSeconds, redirects, funCount) {
  return Math.floor((rescuedSeconds/60) + redirects*5 + funCount*2);
}

// ── XP pop animation ──────────────────────────────────────────────────────────
function showXPPop(amount, x, y) {
  const container = document.getElementById("xpPopContainer");
  const el = document.createElement("div");
  el.className = "xp-pop";
  el.textContent = `+${amount} pts`;
  el.style.left = (x || 140) + "px";
  el.style.top  = (y || 200) + "px";
  container.appendChild(el);
  setTimeout(() => el.remove(), 1600);
}

// ── Share card generator ──────────────────────────────────────────────────────
function generateShareCard(name, avatar, points, savedTime, redirects, streak, badges) {
  const canvas = document.getElementById("shareCanvas");
  const ctx = canvas.getContext("2d");
  const W = 400, H = 300;
  canvas.width = W; canvas.height = H;

  // Background
  const bg = ctx.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, "#0f1e35");
  bg.addColorStop(1, "#020617");
  ctx.fillStyle = bg;
  ctx.roundRect(0, 0, W, H, 18);
  ctx.fill();

  // Glow
  const glow = ctx.createRadialGradient(W*0.15, H*0.2, 0, W*0.15, H*0.2, W*0.5);
  glow.addColorStop(0, "rgba(56,189,248,0.12)");
  glow.addColorStop(1, "transparent");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // Border
  ctx.strokeStyle = "rgba(56,189,248,0.3)";
  ctx.lineWidth = 1.5;
  ctx.roundRect(1, 1, W-2, H-2, 17);
  ctx.stroke();

  // Logo
  ctx.font = "bold 13px system-ui";
  ctx.fillStyle = "#38bdf8";
  ctx.fillText("⏱️  CLOCKED IN", 24, 36);

  // Tagline
  ctx.font = "11px system-ui";
  ctx.fillStyle = "#9ca3af";
  ctx.fillText("Focus. Block. Win.", 24, 54);

  // Avatar circle
  ctx.beginPath();
  ctx.arc(52, 110, 30, 0, Math.PI*2);
  ctx.fillStyle = "rgba(56,189,248,0.12)";
  ctx.fill();
  ctx.strokeStyle = "#38bdf8";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Avatar emoji
  ctx.font = "28px system-ui";
  ctx.textAlign = "center";
  ctx.fillText(avatar || "🧑‍💻", 52, 122);
  ctx.textAlign = "left";

  // Name
  ctx.font = "bold 20px system-ui";
  ctx.fillStyle = "#e5e7eb";
  ctx.fillText(name || "Focus Master", 94, 106);

  // Badges
  if (badges && badges.length > 0) {
    ctx.font = "14px system-ui";
    ctx.fillText(badges.slice(0,5).join(" "), 94, 128);
  }

  // Divider
  ctx.strokeStyle = "rgba(148,163,184,0.15)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(24, 152); ctx.lineTo(W-24, 152);
  ctx.stroke();

  // Stats
  const stats = [
    { label: "Focus Points", value: points.toLocaleString(), color: "#38bdf8" },
    { label: "Time Saved",   value: savedTime,               color: "#22c55e" },
    { label: "Redirects",    value: redirects.toString(),    color: "#e5e7eb" },
    { label: "Day Streak",   value: `${streak}🔥`,           color: "#f97316" },
  ];

  stats.forEach((s, i) => {
    const x = 24 + (i % 2) * 188;
    const y = 180 + Math.floor(i / 2) * 62;
    ctx.fillStyle = "rgba(15,23,42,0.8)";
    ctx.roundRect(x, y, 172, 50, 10);
    ctx.fill();
    ctx.strokeStyle = "rgba(148,163,184,0.15)";
    ctx.lineWidth = 1;
    ctx.roundRect(x, y, 172, 50, 10);
    ctx.stroke();

    ctx.font = "bold 20px system-ui";
    ctx.fillStyle = s.color;
    ctx.fillText(s.value, x+12, y+28);

    ctx.font = "10px system-ui";
    ctx.fillStyle = "#9ca3af";
    ctx.fillText(s.label.toUpperCase(), x+12, y+43);
  });

  // Footer
  ctx.font = "10px system-ui";
  ctx.fillStyle = "rgba(148,163,184,0.5)";
  ctx.textAlign = "center";
  ctx.fillText("clockedin.app • Install the extension and compete!", W/2, H-12);

  document.getElementById("shareOverlay").classList.add("show");
}

// ── Referral ──────────────────────────────────────────────────────────────────
function getReferralLink(userId) {
  return `https://clockedin.app/invite?ref=${userId}`;
}

async function handleReferral() {
  const { clockedInUserId } = await chrome.storage.local.get({ clockedInUserId: "" });
  const link = getReferralLink(clockedInUserId || "user");
  await navigator.clipboard.writeText(link);

  // Give referral badge if not already owned
  const sync = await chrome.storage.sync.get({ ownedBadges: [], spentPoints: 0 });
  if (!sync.ownedBadges.includes("recruiter")) {
    const newBadges = [...sync.ownedBadges, "recruiter"];
    await chrome.storage.sync.set({ ownedBadges: newBadges });
    showXPPop(0, 160, 320);
    const btn = document.getElementById("referralBtn");
    btn.textContent = "🤝 Badge earned!";
    setTimeout(() => btn.textContent = "Copied!", 2000);
  } else {
    const btn = document.getElementById("referralBtn");
    btn.textContent = "✅ Copied!";
    setTimeout(() => btn.textContent = "Copy link", 1500);
  }
}


// ── Pomodoro Timer ────────────────────────────────────────────────────────────
function initPomodoro() {
  let totalSecs    = 25 * 60;
  let remainingSecs = totalSecs;
  let running      = false;
  let interval     = null;
  let isBreak      = false;
  let sessionsComplete = 0;
  const MAX_SESSIONS = 4;

  const timeEl   = document.getElementById("pomoTime");
  const playBtn  = document.getElementById("pomoPlayBtn");
  const resetBtn = document.getElementById("pomoResetBtn");
  const barEl    = document.getElementById("pomoBar");
  const labelEl  = document.getElementById("pomoSessionLabel");

  function getDots() {
    return [0,1,2,3].map(i => document.getElementById("pomoDot" + i));
  }

  function fmt(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  }

  function updateBar() {
    const pct = (remainingSecs / totalSecs) * 100;
    barEl.style.width = pct + "%";
    const warn = pct <= 20 && remainingSecs > 0;
    barEl.className = "pomo-bar-fill" + (isBreak ? " break" : warn ? " warning" : "");
    const warn2 = pct <= 20 && !isBreak && remainingSecs > 0;
    timeEl.className = "pomo-time" + (isBreak ? " break" : running && warn2 ? " warning" : running ? " running" : "");
  }

  function updateDots() {
    getDots().forEach((d, i) => {
      if (d) d.className = "pomo-dot" + (i < sessionsComplete ? " done" : "");
    });
    if (labelEl) {
      if (isBreak) {
        labelEl.textContent = "Break time 🎉";
      } else {
        labelEl.textContent = `Session ${Math.min(sessionsComplete+1, MAX_SESSIONS)} of ${MAX_SESSIONS}`;
      }
    }
  }

  function tick() {
    if (remainingSecs <= 0) {
      clearInterval(interval);
      interval = null;
      running = false;
      playBtn.textContent = "▶";

      if (!isBreak) {
        // Session done
        sessionsComplete = Math.min(sessionsComplete + 1, MAX_SESSIONS);
        updateDots();
        if (sessionsComplete >= MAX_SESSIONS) {
          // All 4 done — big break
          timeEl.textContent = "Done! 🏆";
          barEl.style.width = "100%";
          barEl.className = "pomo-bar-fill break";
          if (labelEl) labelEl.textContent = "All sessions done! Take a long break 🎉";
          sessionsComplete = 0;
          updateDots();
          // Award XP
          showXPPop(50, 140, 200);
          return;
        }
        // Switch to break
        isBreak = true;
        totalSecs = 5 * 60;
        remainingSecs = totalSecs;
      } else {
        // Break done — back to focus
        isBreak = false;
        totalSecs = 25 * 60;
        remainingSecs = totalSecs;
        // Restore active mode button selection
        document.querySelectorAll(".pomo-mode").forEach(b => {
          b.classList.toggle("active", b.dataset.mins === "25" && !b.dataset.break);
        });
      }

      timeEl.textContent = fmt(remainingSecs);
      updateBar();
      updateDots();
      return;
    }

    remainingSecs--;
    timeEl.textContent = fmt(remainingSecs);
    updateBar();
  }

  function start() {
    if (running) return;
    running = true;
    playBtn.textContent = "⏸";
    interval = setInterval(tick, 1000);
    updateBar();
  }

  function pause() {
    if (!running) return;
    running = false;
    playBtn.textContent = "▶";
    clearInterval(interval);
    interval = null;
  }

  function reset() {
    pause();
    remainingSecs = totalSecs;
    timeEl.textContent = fmt(remainingSecs);
    timeEl.className = "pomo-time";
    barEl.style.width = "100%";
    barEl.className = "pomo-bar-fill" + (isBreak ? " break" : "");
  }

  function setMode(mins, breakMode) {
    pause();
    isBreak = !!breakMode;
    totalSecs = mins * 60;
    remainingSecs = totalSecs;
    timeEl.textContent = fmt(remainingSecs);
    timeEl.className = "pomo-time";
    barEl.style.width = "100%";
    barEl.className = "pomo-bar-fill" + (isBreak ? " break" : "");
    updateDots();
  }

  playBtn.addEventListener("click", () => { running ? pause() : start(); });
  resetBtn.addEventListener("click", reset);

  document.querySelectorAll(".pomo-mode").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".pomo-mode").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      setMode(parseInt(btn.dataset.mins), !!btn.dataset.break);
    });
  });

  updateDots();
}

// ── Main ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  const today = todayKey();

  const { sync, local } = await new Promise(resolve => {
    chrome.storage.sync.get(
      { rescuedSecondsToday:0, rescuedDate:"", funCount:0, funDate:"", ownedBadges:[], streakDays:0, displayName:"You", avatar:"🧑‍💻", spentPoints:0 },
      sync => chrome.storage.local.get({ totalRedirects:0, clockedInUserId:"", lastXPRedirects:0 }, local => resolve({ sync, local }))
    );
  });

  const rescuedSecs    = sync.rescuedDate===today ? (sync.rescuedSecondsToday||0) : 0;
  const totalRedirects = local.totalRedirects||0;
  const funCount       = sync.funDate===today ? (sync.funCount||0) : 0;
  const badgeIds       = sync.ownedBadges||[];
  const badges         = badgeIds.map(id => BADGE_MAP[id]||id);
  const streak         = sync.streakDays||0;
  const displayName    = sync.displayName||"You";
  const avatar         = sync.avatar||"🧑‍💻";
  const spentPoints    = sync.spentPoints||0;
  const earned         = computeScore(rescuedSecs, totalRedirects, funCount);
  const points         = Math.max(0, earned - spentPoints);

  // Fill UI
  document.getElementById("profileAvatar").textContent = avatar;
  document.getElementById("profileName").textContent = displayName;
  document.getElementById("streakPill").textContent = `🔥 ${streak}d streak`;
  document.getElementById("statPoints").textContent = points.toLocaleString();
  document.getElementById("statSaved").textContent = formatDuration(rescuedSecs);
  document.getElementById("statRedirects").textContent = totalRedirects.toLocaleString();
  document.getElementById("statBadges").textContent = badgeIds.length;
  document.getElementById("profileBadges").innerHTML = badges.slice(0,5).map(b=>`<span>${b}</span>`).join("");
  document.getElementById("profileRank").textContent = `${points} focus pts earned`;

  // Daily challenge
  const daily = getDailyChallenge();
  const typeEl = document.getElementById("dailyType");
  typeEl.textContent = daily.type === "truth" ? "✨ Truth" : "🎯 Dare";
  typeEl.className = "daily-type " + daily.type;
  document.getElementById("dailyText").textContent = daily.text;

  // Pomodoro
  initPomodoro();

  // XP pop for new redirects since last open
  const lastXP = local.lastXPRedirects || 0;
  const newRedirects = totalRedirects - lastXP;
  if (newRedirects > 0) {
    const xpEarned = newRedirects * 5;
    setTimeout(() => showXPPop(xpEarned, 80 + Math.random()*160, 160 + Math.random()*80), 400);
    chrome.storage.local.set({ lastXPRedirects: totalRedirects });
  }

  // Share card
  document.getElementById("shareBtn").addEventListener("click", () => {
    generateShareCard(displayName, avatar, points, formatDuration(rescuedSecs), totalRedirects, streak, badges);
  });

  document.getElementById("downloadBtn").addEventListener("click", () => {
    const canvas = document.getElementById("shareCanvas");
    const a = document.createElement("a");
    a.download = "clocked-in-stats.png";
    a.href = canvas.toDataURL("image/png");
    a.click();
  });

  document.getElementById("closeShare").addEventListener("click", () => {
    document.getElementById("shareOverlay").classList.remove("show");
  });

  // Referral
  document.getElementById("referralBtn").addEventListener("click", handleReferral);
});
