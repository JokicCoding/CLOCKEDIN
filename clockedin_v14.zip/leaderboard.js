/**
 * leaderboard.js — Clocked In v4
 * Uses Firestore REST API directly (no SDK) — works reliably in MV3 extensions.
 */

const PROJECT_ID = "clocked-7ca13";
const API_KEY    = "AIzaSyBmd5zGpqdIJef3IPRXWQNk2QYNZkFdUDg";
const BASE_URL   = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;

const BADGE_MAP = {
  first_block:"🛡️", focus_starter:"🎯", deep_work:"🧠", flow_state:"⚡",
  iron_will:"🏰", no_scroll:"🚫", truth_seeker:"💬", dare_devil:"🌶️",
  game_master:"🎲", laugh_riot:"😂", two_day:"📅", one_week:"🔥",
  two_weeks:"🌟", monthly:"🏅", night_owl:"🦉", early_bird:"🌅",
  digital_zen:"🌙", wiki_wanderer:"📚", golden_clock:"🏆",
};

function badgeIdsToEmojis(ids) {
  return (ids||[]).map(id => BADGE_MAP[id]||id).filter(Boolean);
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function formatDuration(s) {
  s = Math.max(0, Math.floor(Number(s)||0));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s/60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m/60), r = m%60;
  return r===0 ? `${h}h` : `${h}h ${r}m`;
}

function computeScore(rescuedSeconds, redirects, funCount) {
  return Math.floor((rescuedSeconds/60) + redirects*5 + funCount*2);
}

function getUserId() {
  return new Promise(resolve => {
    chrome.storage.local.get({ clockedInUserId: "" }, data => {
      if (data.clockedInUserId) return resolve(data.clockedInUserId);
      const id = "user_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
      chrome.storage.local.set({ clockedInUserId: id }, () => resolve(id));
    });
  });
}

function setStatus(msg, color) {
  const el = document.getElementById("liveStatus");
  if (el) { el.textContent = msg; el.style.color = color || "#9ca3af"; }
}

// ── Firestore REST helpers ────────────────────────────────────────────────────

// Convert Firestore REST value to JS
function fromFirestore(val) {
  if (!val) return null;
  if ("stringValue"  in val) return val.stringValue;
  if ("integerValue" in val) return Number(val.integerValue);
  if ("doubleValue"  in val) return val.doubleValue;
  if ("booleanValue" in val) return val.booleanValue;
  if ("arrayValue"   in val) return (val.arrayValue.values||[]).map(fromFirestore);
  if ("mapValue"     in val) {
    const obj = {};
    for (const [k,v] of Object.entries(val.mapValue.fields||{})) obj[k] = fromFirestore(v);
    return obj;
  }
  return null;
}

// Convert JS value to Firestore REST value
function toFirestore(val) {
  if (typeof val === "string")  return { stringValue: val };
  if (typeof val === "number")  return Number.isInteger(val) ? { integerValue: String(val) } : { doubleValue: val };
  if (typeof val === "boolean") return { booleanValue: val };
  if (Array.isArray(val))       return { arrayValue: { values: val.map(toFirestore) } };
  if (val === null || val === undefined) return { nullValue: null };
  return { stringValue: String(val) };
}

async function firestoreSet(collection, docId, data) {
  const fields = {};
  for (const [k, v] of Object.entries(data)) fields[k] = toFirestore(v);
  const url = `${BASE_URL}/${collection}/${docId}?key=${API_KEY}&updateMask.fieldPaths=${Object.keys(data).join("&updateMask.fieldPaths=")}`;
  const res = await fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields })
  });
  if (!res.ok) throw new Error(`Write failed: ${res.status} ${await res.text()}`);
  return res.json();
}

async function firestoreQuery(collection) {
  const url = `${BASE_URL}:runQuery?key=${API_KEY}`;
  const body = {
    structuredQuery: {
      from: [{ collectionId: collection }],
      orderBy: [{ field: { fieldPath: "score" }, direction: "DESCENDING" }],
      limit: 50
    }
  };
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`Read failed: ${res.status} ${await res.text()}`);
  const rows = await res.json();
  return rows
    .filter(r => r.document)
    .map(r => {
      const id = r.document.name.split("/").pop();
      const fields = {};
      for (const [k,v] of Object.entries(r.document.fields||{})) fields[k] = fromFirestore(v);
      return { id, ...fields };
    });
}

// ── Render ────────────────────────────────────────────────────────────────────
function renderPodium(users, myId) {
  const el = document.getElementById("podium");
  if (!el) return;
  const top3 = users.slice(0,3);
  const order = [top3[1], top3[0], top3[2]].filter(Boolean);
  const rankNums = top3[1] ? [2,1,3] : [1,2,3];
  const rankClasses = top3[1] ? ["rank-2","rank-1","rank-3"] : ["rank-1","rank-2","rank-3"];
  el.innerHTML = "";
  order.forEach((user, i) => {
    const rn = rankNums[i];
    const isYou = user.id === myId;
    const div = document.createElement("div");
    div.className = `podium-item ${rankClasses[i]}`;
    div.innerHTML = `
      <div class="podium-avatar">${rn===1?'<span class="crown">👑</span>':""}${user.avatar||"🧑‍💻"}</div>
      <div class="podium-name">${user.displayName}${isYou?" (You)":""}</div>
      <div class="podium-score"><span>${(user.score||0).toLocaleString()} pts</span></div>
      ${user.badges?.length?`<div class="podium-badges">${user.badges.slice(0,3).map(b=>`<span>${b}</span>`).join("")}</div>`:""}
      <div class="podium-bar">${rn}</div>`;
    el.appendChild(div);
  });
}

function renderTable(users, myId) {
  const el = document.getElementById("rankTable");
  if (!el) return;
  const maxScore = users[0]?.score || 1;
  el.innerHTML = "";
  users.forEach((user, i) => {
    const rank = i+1;
    const isYou = user.id === myId;
    const icon = rank===1?"🥇":rank===2?"🥈":rank===3?"🥉":`#${rank}`;
    const cls  = rank===1?"gold":rank===2?"silver":rank===3?"bronze":"";
    const row  = document.createElement("div");
    row.className = `rank-row${isYou?" you":""}`;
    row.innerHTML = `
      <div class="rank-pos ${cls}">${icon}</div>
      <div class="rank-user">
        <div class="rank-avatar">${user.avatar||"🧑‍💻"}</div>
        <div><span class="rank-name">${user.displayName}</span>${isYou?'<span class="you-tag">YOU</span>':""}</div>
      </div>
      <div class="rank-badges">${(user.badges||[]).slice(0,5).map(b=>`<span class="mini-badge">${b}</span>`).join("")}</div>
      <div class="rank-score">${(user.score||0).toLocaleString()}<small>pts</small></div>`;
    el.appendChild(row);
    const bar = document.createElement("div");
    bar.className = "rank-bar-wrap";
    bar.innerHTML = `<div class="rank-bar-fill" style="width:${Math.round((user.score||0)/maxScore*100)}%"></div>`;
    el.appendChild(bar);
  });
}

// ── Main ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  setStatus("⏳ Connecting…");
  const today = todayKey();

  const { sync, local } = await new Promise(resolve => {
    chrome.storage.sync.get(
      { rescuedSecondsToday:0, rescuedDate:"", funCount:0, funDate:"", ownedBadges:[], streakDays:0, displayName:"You", avatar:"🧑‍💻", spentPoints:0 },
      sync => chrome.storage.local.get({ totalRedirects:0 }, local => resolve({ sync, local }))
    );
  });

  const rescuedSecs    = sync.rescuedDate===today ? (sync.rescuedSecondsToday||0) : 0;
  const totalRedirects = local.totalRedirects||0;
  const funCount       = sync.funDate===today ? (sync.funCount||0) : 0;
  const badgeIds       = sync.ownedBadges||[];
  const badges         = badgeIdsToEmojis(badgeIds);
  const streak         = sync.streakDays||0;
  const displayName    = sync.displayName||"You";
  const avatar         = sync.avatar||"🧑‍💻";
  const spentPoints    = sync.spentPoints||0;
  const earned         = computeScore(rescuedSecs, totalRedirects, funCount);
  const myScore        = Math.max(0, earned - spentPoints);
  const userId         = await getUserId();

  // Fill stats card
  document.getElementById("yourPoints").textContent = myScore.toLocaleString();
  document.getElementById("totalRedirects").textContent = totalRedirects.toLocaleString();
  document.getElementById("metricStreak").textContent = `${streak}d`;
  document.getElementById("metricSaved").textContent = formatDuration(rescuedSecs);
  document.getElementById("metricFun").textContent = `${funCount}x`;
  document.getElementById("metricBadges").textContent = badgeIds.length;
  document.getElementById("yourStreakText").textContent = streak>0 ? `${streak}-day focus streak 🔥` : "Start your streak today!";
  const avatarEl = document.getElementById("yourAvatarEl");
  if (avatarEl) avatarEl.textContent = avatar;
  const nameEl = document.getElementById("yourNameEl");
  if (nameEl) nameEl.textContent = displayName;
  const badgesEl = document.getElementById("yourBadgesDisplay");
  if (badgesEl && badges.length>0) badgesEl.innerHTML = badges.map(b=>`<span style="font-size:1.2rem">${b}</span>`).join(" ");

  try {
    // Push my score
    setStatus("⏳ Uploading your score…");
    await firestoreSet("leaderboard", userId, {
      displayName, avatar, score: myScore,
      badges: JSON.stringify(badges), // store as string since array needs special handling
      streak
    });

    // Fetch all
    setStatus("⏳ Fetching global scores…");
    let users = await firestoreQuery("leaderboard");

    // badges stored as JSON string — parse back
    users = users.map(u => ({
      ...u,
      badges: typeof u.badges === "string" ? JSON.parse(u.badges||"[]") : (u.badges||[])
    }));

    const myRank = users.findIndex(u => u.id===userId)+1;
    document.getElementById("yourRank").textContent = myRank ? `#${myRank}` : `#${users.length+1}`;
    document.getElementById("rankChange").textContent = myRank<=3 ? `🏆 Top ${myRank} globally!` : `Rank #${myRank} of ${users.length} users`;

    renderPodium(users, userId);
    renderTable(users, userId);
    setStatus(`🟢 Live · ${users.length} user${users.length!==1?"s":""} on the board`, "#22c55e");

    // Poll for updates every 30s (REST API doesn't support real-time, but close enough)
    setInterval(async () => {
      try {
        let fresh = await firestoreQuery("leaderboard");
        fresh = fresh.map(u => ({
          ...u,
          badges: typeof u.badges === "string" ? JSON.parse(u.badges||"[]") : (u.badges||[])
        }));
        const r = fresh.findIndex(u => u.id===userId)+1;
        document.getElementById("yourRank").textContent = r ? `#${r}` : "-";
        document.getElementById("rankChange").textContent = r<=3 ? `🏆 Top ${r} globally!` : `Rank #${r} of ${fresh.length} users`;
        renderPodium(fresh, userId);
        renderTable(fresh, userId);
        setStatus(`🟢 Live · ${fresh.length} user${fresh.length!==1?"s":""} · just refreshed`, "#22c55e");
      } catch(_) {}
    }, 30000);

  } catch(e) {
    setStatus("❌ " + e.message, "#f97373");
    console.error("Firestore error:", e);
  }

  document.querySelectorAll(".filter-tab").forEach(tab => {
    tab.addEventListener("click", async () => {
      document.querySelectorAll(".filter-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      try {
        let users = await firestoreQuery("leaderboard");
        users = users.map(u => ({ ...u, badges: typeof u.badges==="string"?JSON.parse(u.badges||"[]"):(u.badges||[]) }));
        renderPodium(users, userId);
        renderTable(users, userId);
      } catch(_) {}
    });
  });
});
